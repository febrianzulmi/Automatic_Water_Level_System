from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, make_response
from werkzeug.utils import secure_filename
import json, os, sys, subprocess, psutil, socket, shutil, requests, io, datetime
import pyexcel as pe
import pandas as pd
sys.path.append('../database')
from sql import *
from sql_connex import *
from function import *

project_name, project_port, project_gateway, project_node, project_protocol = getData()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'project'
    
@app.route('/get/time')
def get_time():
    datetime = times.now()
    day = int(datetime.strftime("%w"))
    month = int(datetime.strftime("%m"))
    hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu']
    bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']
    datetime = datetime.strftime(hari[day] + ", %d " + bulan[month-1] + " %Y %H:%M:%S")
    #datetime = datetime.strftime("%A, %d %B %Y %H:%M:%S")
    return datetime

@app.route('/api/sensor/<sensors>', methods=['GET'])
def api_sensor(sensors):
    group, stateGroup = processApiPRTG(sensors, None)
    dataSensor = getDataSensor.all()   
    returnApi = {"prtg":{}}
    returnApi['prtg'] = {'result':[]}
    if int(stateGroup) == 1:
       if dataSensor['num_sensor'] > 0:
          for x in range(dataSensor['num_sensor']):
              if group == 'connex':
                 if dataSensor['group_id'][x] == 1 or dataSensor['group_id'][x] == 2: 
                    returnApi = createApiPRTG(dataSensor, returnApi, x, None, None, 'groupOnly') 
              else:    
                 if dataSensor['group_id'][x] == group:
                    returnApi = createApiPRTG(dataSensor, returnApi, x, None, None, 'groupOnly')
    return json.dumps(returnApi)  

@app.route('/api/sensor/<sensors>/<priority>', methods=['GET'])
def api_sensors(sensors,priority):
    group, stateGroup, monitor, log = processApiPRTG(sensors, priority)
    dataSensor = getDataSensor.all()   
    returnApi = {"prtg":{}}
    returnApi['prtg'] = {'result':[]}
    if int(stateGroup) == 1 and int(priority) >=0 and int(priority) <=6:
       if dataSensor['num_sensor'] > 0:
          for x in range(dataSensor['num_sensor']):
              if group == 'connex':
                 if dataSensor['group_id'][x] == 1 or dataSensor['group_id'][x] == 2: 
                    returnApi = createApiPRTG(dataSensor, returnApi, x, log, monitor, 'groupPriority') 
              else:    
                 if dataSensor['group_id'][x] == group:
                    returnApi = createApiPRTG(dataSensor, returnApi, x, log, monitor, 'groupPriority')
    return json.dumps(returnApi)
    
@app.route('/')
def index():
    rule = str(request.url_rule)
    id, username, state, level = checkSession()
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    node_id, name, ip, firm_user, firm_pass = getSetting()
    scc_id, scc_name = getSCC()
    data_log = statistic.select()
    send_node, buffer_node, send_node2 = 0, 0, 0
    if len(data_log) > 0:
       for x in range(len(data_log)):
           if data_log[x][1] == 'monitoring':
              monitor_log = data_log[x][2] 
           elif data_log[x][1] == 'buffer':
              buffer_log = data_log[x][2] 
           elif data_log[x][1] == 'log':
              sensor_log = data_log[x][2]
           elif data_log[x][1] == 'notif':
              notif_log = data_log[x][2]               
    else:
       monitor_log, buffer_log, sensor_log, notif_log = 0, 0, 0, 0
    info_node, node_service = [], 0
    def parseData(name, serviceName, serviceData, serviceNum):
        service, state, last_update = getServiceState(serviceName)
        if service == 'active':
           serviceNum +=1    
        serviceInfo = [name, service, state, last_update]
        serviceData.append(serviceInfo)    
        return serviceData, serviceNum            
    info_node, node_service = parseData('Routine Monitoring', 'connex_routine', info_node, node_service)
    info_node, node_service = parseData('Accident Monitoring', 'connex_accident', info_node, node_service)
    info_node, node_service = parseData('Display', 'connex_display', info_node, node_service)
    info_node, node_service = parseData('Buffer', 'connex_buffer', info_node, node_service)
    info_node, node_service = parseData('Log', 'connex_log', info_node, node_service)
    info_node, node_service = parseData('Synchronize', 'connex_sync', info_node, node_service)
    info_node, node_service = parseData('Authentication', 'connex_auth', info_node, node_service)
    info_node, node_service = parseData('Notification', 'connex_notif', info_node, node_service)
    if node_service == 8:
       node_service = 'OK'
    else:
       node_service = 'Warning'
    group_sensor = groups.select()
    info_group, sensor_service = [], 0
    if len(group_sensor) > 0:
       for i in range(len(group_sensor)):
           info_group, sensor_service = parseData(group_sensor[i][1], 'sensor' + str(group_sensor[i][0]), info_group, sensor_service)
       if sensor_service == len(group_sensor):
          sensor_service = 'OK'
       else:
          sensor_service = 'Warning'
    sensors = sensor.select()
    info_sensor, oid_data = [], []
    if len(sensors) > 0:
       for i in range(len(sensors)):
           group = groups.selectOne(sensors[i][2])
           for y in group:
               group_name = y[1]
           base_oid = getBaseOID(sensors[i][2])
           oid = base_oid + "." + str(sensors[i][3])
           from puresnmp import get
           ip = '127.0.0.1'
           get_community = snmp.selectByName("community")
           for x in get_community:
               snmp_community = x[0]
           try:
              result = get(ip, snmp_community, oid)
              if sensors[i][13] == 0:
                 oid_raw = result
                 oid_value = result/100
              else:
                 oid_raw = result
                 oid_value = result.decode()      
           except Exception as e:
              if sensors[i][13] == 0:
                 oid_raw = 0
                 oid_value = 0.00
              else:
                 oid_raw = b'N/A'
                 oid_value = 'N/A'
           value, timestamp = sensors[i][5], sensors[i][6]
           if value == None:
              value, timestamp = '-', '-'                         
           datas = [group_name, sensors[i][4], value, timestamp]
           info_sensor.append(datas)
           oid_data.append([oid, group_name, sensors[i][4], oid_raw, oid_value])
    if node_service == 'OK' and sensor_service == 'OK':
       overall = 'OK'
    else:
       overall = 'Warning'         
    return render_template('index.html', project_port=project_port, project_name=project_name, project_gateway=project_gateway, 
                           project_node=project_node, project_protocol=project_protocol, rule=rule, node_id=node_id, name=name, sensors=sensors, monitor_log=monitor_log,
                           buffer_log=buffer_log, sensor_log= sensor_log, state=state, username=username, info_sensor=info_sensor, info_group=info_group, info_node=info_node,
                           node_service=node_service, sensor_service=sensor_service, overall=overall, oid_data=oid_data, scc_name=scc_name, notif_log=notif_log)

@app.route('/login')
def login():
    id, username, state, level = checkSession()
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    rule = str(request.url_rule)
    return render_template('login.html', project_port=project_port, project_name=project_name, project_gateway=project_gateway, 
                           project_node=project_node, project_protocol=project_protocol, rule=rule, state=state, username=username)

@app.route('/login', methods=['POST'])
def login_post():
    username2 = request.form.get('username')
    password2 = request.form.get('password')
    flag = request.form.get('flag')
    port = getPort()
    data = {"username":username2,"password":password2,"flag":flag}
    try:
       login = requests.post('http://localhost:' + port + '/api/project/login', data=data)
       check = login.text
    except Exception as e:
       check = 0
    if check == "2":
       return redirect(url_for('index'))
    elif check == "1": 
       flash('Wrong Password. Please Check Your Login and Try Again') 
       return redirect(url_for('login'))  
    else:
       flash('Wrong Username. Please Check Your Login and Try Again')
       return redirect(url_for('login'))

@app.route('/logout')
def logout():
    id, username, state, level = checkSession()
    port = getPort()
    data = {"id":id}
    try:
       logout = requests.post('http://localhost:' + port + '/api/project/logout', data=data)
    except:
       pass
    return redirect(url_for('index'))
       
@app.route('/setting')
def setting_form():
    id, username, state, level = checkSession()
    tab = request.args['tab']
    rule = str(request.url_rule)
    groupID, groupID2, groupID3 = 'All', 'All', 'All'
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    node_id, name, ip, firm_user, firm_pass = getSetting()
    stateToken, tokens, expireToken = checkTokenHTTP()
    monitoring, sync, log, notif = getConnexSetting()
    scc_id, scc_name = getSCC()
    group = groups.select()
    sensors = sensor.select()
    sensorAll = sensor.select()
    param = params.select()
    param2 = paramList.select()
    monitorInterval = getInterval("monitoring")
    logInterval = getInterval("Log")
    oid = []
    if 'group' in request.args:
       if request.args['tab'] == 'sensor-list':
          groupID = request.args['group']
          if groupID != 'All':
             sensors = sensor.selectByGroupFull(groupID)  
       elif request.args['tab'] == 'sensor-param-group':
          groupID2 = request.args['group']
          if groupID2 != 'All':
             param = params.selectByGroupFull(groupID2)
       elif request.args['tab'] == 'sensor-param-list':
          groupID3 = request.args['group']
          if groupID3 != 'All':
             param2 = paramList.selectByGroupFull(groupID3)      
    for i in range(len(sensors)):
        base = params.selectByGroupParameter(sensors[i][2], "parent_oid")
        base_oid = 'Undefined'
        for i in base:
            base_oid = i[4]   
        oid.append(base_oid)
    formulas = calibrateFormula.select()
    scc = sccType.select()
    scc_param = sccParam.select()
    scc_config = sccConfig.select()
    scc_value = sccValue.select()
    interval = intervals.select()
    attribute = attributes.select()
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))  
    return render_template('setting.html', project_port=project_port, project_name=project_name, project_gateway=project_gateway, project_node=project_node, level=level,
                           node_id=node_id, name=name, ip=ip, firm_user=firm_user, firm_pass=firm_pass, attribute=attribute, sensors=sensors, interval=interval, group=group,
                           param=param, param2=param2, project_protocol=project_protocol, rule=rule, state=state, username=username, oid=oid, tab=tab, formulas=formulas, monitoring=monitoring,
                           sync=sync, scc=scc, scc_param=scc_param, scc_config=scc_config, scc_value=scc_value, scc_id=scc_id, groupID=groupID, groupID2=groupID2, groupID3=groupID3,
                           sensorAll=sensorAll, log=log, notif=notif, tokens=tokens, expireToken=expireToken, monitorInterval=monitorInterval, logInterval=logInterval)

@app.route('/setting_post', methods=['POST'])
def setting_post():
    import random, string
    node_id = request.form.get('node_id')
    name = request.form.get('name')
    ip = request.form.get('ip')
    firm_user = request.form.get('firm_user')
    firm_pass = request.form.get('firm_pass')
    sync = request.form.get('sync')
    monitoring = request.form.get('monitoring')
    log = request.form.get('log')
    notif = request.form.get('notif')
    scc_id = request.form.get('scc_id')
    if scc_id != '':
       getConfig = sccConfig.select()
       if len(getConfig) > 0:
          for i in range(len(getConfig)):
              id = getConfig[i][0]
              config_name = getConfig[i][2]
              scc_id_last = getConfig[i][1]
              if scc_id != scc_id_last:
                 sccValue.deleteByConfig(id)
                 getParam = sccParam.selectBySCC(scc_id)
                 if len(getParam) > 0:
                    for x in range(len(getParam)):
                        value_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
                        param_id = getParam[x][0]
                        sccValue.insert(value_id, id, param_id, "N/A")
              updates = sccConfig.update(scc_id,config_name,id)
    fetch = setting.select()
    if node_id == '':
       node_id = 0
    if len(fetch) == 0:
       inserts = setting.insert(node_id,name,ip,firm_user,firm_pass,monitoring,sync,scc_id,log,notif)
    else:
       updates = setting.update(node_id,name,ip,firm_user,firm_pass,monitoring,sync,scc_id,log,notif)
    return redirect(url_for('setting_form', tab='parameter'))
    
@app.route('/token/reset')
def token_reset():
    token.updateValueByName("N/A", "token")
    token.updateValueByName("N/A", "expire")
    token.updateValueByName(0, "state")
    return redirect(url_for('setting_form', tab='token'))

@app.route('/token/get')
def token_get():
    fetch = setting.select()
    for i in fetch:
        node_id = i[1]
        ip = i[3]
        port = i[4]
        key = i[5]
    cek = attributes.selectOne("auth")
    if len(cek) > 0:
       for i in cek:
           param = i[2]
           link = 'http://'+ip+':'+port+param
           print('URL : ',link)
           user = packData.userPack(node_id, key)
           auth = http.getToken(link, user)
           if auth != 'Failed Get Token':
              update =  setting.updateToken(auth)
    return redirect(url_for('setting_form'))

@app.route('/attribute_post', methods=['POST'])
def attribute_post():
    name = request.form.get('name')
    value = request.form.get('value')
    inserts = attributes.insert(name,value)
    return redirect(url_for('setting_form', tab='api'))

@app.route('/attribute_update/<id>', methods=['POST'])
def attribute_update(id):
    name = request.form.get('name')
    value = request.form.get('value')
    updates = attributes.update(name,value,id)
    return redirect(url_for('setting_form', tab='api'))

@app.route('/attribute_delete/<id>')
def attribute_delete(id):
    deletes = attributes.deleteOne(id)
    return redirect(url_for('setting_form', tab='api'))

@app.route('/interval/add', methods=['POST'])
def interval_post():
    name = request.form.get('name')
    interval = request.form.get('interval')
    unit = request.form.get('unit')
    inserts = intervals.insert(name,interval,unit)
    return redirect(url_for('setting_form', tab='interval'))

@app.route('/interval/update/<id>', methods=['POST'])
def interval_update(id):
    name = request.form.get('name')
    interval = request.form.get('interval')
    unit = request.form.get('unit')
    updates = intervals.update(name,interval,unit,id)
    return redirect(url_for('setting_form', tab='interval'))

@app.route('/interval/delete/<id>')
def interval_delete(id):
    deletes = intervals.deleteOne(id)
    return redirect(url_for('setting_form', tab='interval'))

@app.route('/gateway/add', methods=['POST'])
def gateway_post():
    value = request.form.get('value')
    gateways = gateway.select()
    if len(gateways) == 0:
       inserts = gateway.insert(value)
    else:
       updates = gateway.update(value)
    return redirect(url_for('setting_form'))

@app.route('/sensor/add', methods=['POST'])
def sensor_post():
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    sensor_id = request.form.get('sensor_id')
    name = request.form.get('name')
    group_id = request.form.get('group_id')
    oid = request.form.get('oid')
    calibrate = request.form.get('calibrate')
    formula = request.form.get('formula')
    oid_tipe = request.form.get('oid_tipe')
    log = request.form.get('log')
    monitor = request.form.get('monitor')
    inserts = sensor.insert(sensor_id,oid,group_id,name,calibrate,formula,oid_tipe,monitor,log)
    #if int(project_protocol) == 3:
    createOID()
    return redirect(url_for('setting_form', tab='sensor-list'))

@app.route('/sensor/update/<id>', methods=['POST'])
def sensor_update(id):
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    groupNow = request.form.get('groupNow')
    sensor_id = request.form.get('sensor_id')
    name = request.form.get('name')
    group_id = request.form.get('group_id')
    last_oid_data = request.form.get('oid')
    sensors  = sensor.select()
    calibrate = request.form.get('calibrate')
    formula = request.form.get('formula')
    oid_tipe = request.form.get('oid_tipe')
    log = request.form.get('log')
    monitor = request.form.get('monitor')
    if len(sensors) > 0:
       for i in range(len(sensors)):
           base_oid = getBaseOID(sensors[i][2])
           last_oid = sensors[i][3]
           oid = base_oid + "." + str(last_oid)
           script = "sudo rm /tmp/" + oid
           os.system(script)
    updates = sensor.update(sensor_id,last_oid_data,group_id,name,calibrate,formula,oid_tipe,monitor,log,id)
    createOID()
    return redirect(url_for('setting_form', tab='sensor-list', group=groupNow))

@app.route('/sensor/delete/<id>', methods=['POST'])
def sensor_delete(id):
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    deletes = sensor.deleteOne(id)
    groupNow = request.form.get('groupNow')
    #if int(project_protocol) == 3:
    createOID()
    return redirect(url_for('setting_form', tab='sensor-list', group=groupNow))

@app.route('/sensor/filter', methods=['POST'])
def sensor_filter():
    groupID = request.form.get('groupID')
    return redirect(url_for('setting_form', tab='sensor-list', group=groupID))   

@app.route('/param/add', methods=['POST'])
def param_post():
    group_id = request.form.get('group_id')
    name = request.form.get('name')
    parameter = request.form.get('parameter')
    value = request.form.get('value')
    inserts = params.insert(group_id,name,parameter,value)
    return redirect(url_for('setting_form', tab='sensor-param-group'))

@app.route('/param/update/<id>', methods=['POST'])
def param_update(id):
    groupNow = request.form.get('groupNow')
    group_id = request.form.get('group_id')
    name = request.form.get('name')
    parameter = request.form.get('parameter')
    value = request.form.get('value')
    updates = params.update(group_id,name,parameter,value,id)
    return redirect(url_for('setting_form', tab='sensor-param-group', group=groupNow))

@app.route('/param/delete/<id>', methods=['POST'])
def param_delete(id):
    groupNow = request.form.get('groupNow')
    deletes = params.deleteOne(id)
    return redirect(url_for('setting_form', tab='sensor-param-group', group=groupNow))

@app.route('/param/filter', methods=['POST'])
def param_filter():
    groupID = request.form.get('groupID')
    return redirect(url_for('setting_form', tab='sensor-param-group', group=groupID)) 

@app.route('/param/sensor/add', methods=['POST'])
def paramList_post():
    sensor_id = request.form.get('sensor_id')
    name = request.form.get('name')
    parameter = request.form.get('parameter')
    value = request.form.get('value')
    inserts = paramList.insert(sensor_id,name,parameter,value)
    return redirect(url_for('setting_form', tab='sensor-param-list'))

@app.route('/param/sensor/update/<id>', methods=['POST'])
def paramList_update(id):
    groupNow = request.form.get('groupNow')
    sensor_id = request.form.get('sensor_id')
    name = request.form.get('name')
    parameter = request.form.get('parameter')
    value = request.form.get('value')
    updates = paramList.update(sensor_id,name,parameter,value,id)
    return redirect(url_for('setting_form', tab='sensor-param-list', group=groupNow))

@app.route('/param/sensor/delete/<id>', methods=['POST'])
def paramList_delete(id):
    groupNow = request.form.get('groupNow')
    deletes = paramList.deleteOne(id)
    return redirect(url_for('setting_form', tab='sensor-param-list', group=groupNow))

@app.route('/param/sensor/filter', methods=['POST'])
def paramList_filter():
    groupID = request.form.get('groupID')
    return redirect(url_for('setting_form', tab='sensor-param-list', group=groupID))     

@app.route('/group/add', methods=['POST'])
def group_post():
    base = "/home/pi/"
    name = request.form.get('name')
    interval = request.form.get('interval')
    unit = request.form.get('unit')
    frekuensi = request.form.get('frekuensi')
    inserts = groups.insert(name,interval,unit,frekuensi,0)
    select = groups.selectByName(name)
    print(select)
    for i in range(len(select)):
        group_id = select[i][0]
    filename1 = "sensor" + str(group_id)
    filename2 = "check_sensor" + str(group_id)
    def file_read(source):
        f = open(source, 'r')
        data = f.readlines()
        f.close()
        return data
    def file_write(source, data):
        f = open(source, 'w')
        f.writelines(data)
        f.close()
    data = file_read(base + 'platform/storage/service.master')
    command = "/usr/bin/python3.7 " + filename1 + ".py"
    path = base + "project/sensor/"
    data[5] = "ExecStart={}\n".format(command)
    data[6] = "WorkingDirectory={}\n".format(path)
    file_write('/lib/systemd/system/' + filename1 + '.service', data)
    port = getPort()
    url = "http://localhost:" + port
    data = {"name":filename1, "path":path, "command":command}
    send = requests.post(url + "/api/service", data=data)
    fetch = requests.get(url + "/api/service/" + filename1)
    fetch = fetch.text
    fetch = json.loads(fetch)
    service_id = fetch['id']
    updates = groups.update(name,interval,unit,frekuensi,service_id,group_id)
    filesensor1 = base + 'project/sensor/sensor' + str(group_id) + '.py' 
    filesensor2 = base + 'project/sensor/check_sensor' + str(group_id) + '.py'
    shutil.copy(base + "platform/storage/sensor/sensor.py", filesensor1)
    shutil.copy(base + "platform/storage/sensor/check_sensor.py", filesensor2)
    data1 = file_read(filesensor1)
    data1[0] = 'group_id = ' + str(group_id) + '\n'
    file_write(filesensor1, data1)
    data2 = file_read(filesensor2)
    data2[0] = 'group_id = ' + str(group_id) + '\n'
    file_write(filesensor2, data2)
    return redirect(url_for('setting_form', tab='sensor-group'))

@app.route('/group/update/<id>', methods=['POST'])
def group_update(id):
    name = request.form.get('name')
    interval = request.form.get('interval')
    unit = request.form.get('unit')
    frekuensi = request.form.get('frekuensi')
    service_id = request.form.get('service_id')
    updates = groups.update(name,interval,unit,frekuensi,service_id,id)
    return redirect(url_for('setting_form', tab='sensor-group'))

@app.route('/group/delete/<id>')
def group_delete(id):
    base = "/home/pi/"
    fetch = groups.selectOne(id)
    for i in fetch:
        service_id = i[5]
    port = getPort()
    url = "http://localhost:" + port
    fetch = requests.get(url + "/api/service/delete/" + str(service_id))
    deletes = groups.deleteOne(id)
    os.system("sudo rm " + base + "project/sensor/sensor" + id + ".py")
    os.system("sudo rm " + base + "project/sensor/check_sensor" + id + ".py")
    os.system("sudo systemctl stop sensor" + id)
    os.system("sudo rm " + base + "/lib/systemd/system/sensor" + id + ".service")
    os.system("sudo systemctl daemon-reload")
    return redirect(url_for('setting_form', tab='sensor-group'))

@app.route('/scc/add', methods=['POST'])
def scc_post():
    import random, string
    scc_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(5)])
    name = request.form.get('name')
    sensor = request.form.get('sensor')
    inserts = sccType.insert(scc_id,name,sensor)
    return redirect(url_for('setting_form', tab='scc'))

@app.route('/scc/update/<id>', methods=['POST'])
def scc_update(id):
    name = request.form.get('name')
    sensor = request.form.get('sensor')
    updates = sccType.update(name,sensor,id)
    return redirect(url_for('setting_form', tab='scc'))

@app.route('/scc/delete/<id>')
def scc_delete(id):
    updates = sccType.deleteOne(id)
    return redirect(url_for('setting_form', tab='scc'))        

@app.route('/scc/param/add', methods=['POST'])
def scc_param_post():
    import random, string
    param_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(5)])
    scc_id = request.form.get('scc_id')
    parameter = request.form.get('parameter')
    name = request.form.get('name')
    inserts = sccParam.insert(param_id,scc_id,name,parameter)
    getConfig = sccConfig.selectBySCC(scc_id)
    if len(getConfig) > 0:
       for x in range(len(getConfig)):
           config_id = getConfig[x][0]
           value_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
           sccValue.insert(value_id, config_id, param_id, "N/A")
    return redirect(url_for('setting_form', tab='scc'))
   
@app.route('/scc/param/update/<id>', methods=['POST'])
def scc_param_update(id):
    import random, string
    scc_id = request.form.get('scc_id')
    parameter = request.form.get('parameter')
    name = request.form.get('name')
    getParam = sccParam.selectById(id)
    if len(getParam) > 0:
       for i in getParam:
           scc_id_last = i[1]
       if scc_id != scc_id_last:
          getLastConfig = sccConfig.selectBySCC(scc_id_last)
          if len(getLastConfig) > 0:
             for x in range(len(getLastConfig)):
                 config_id_last = getLastConfig[x][0]
                 sccValue.deleteByConfigParam(config_id_last, id)
          getConfig = sccConfig.selectBySCC(scc_id)
          if len(getConfig) > 0:
             for y in range(len(getConfig)):
                 config_id = getConfig[y][0]
                 value_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
                 sccValue.insert(value_id, config_id, id, "N/A")               
    updates = sccParam.update(scc_id,name,parameter,id)
    return redirect(url_for('setting_form', tab='scc'))

@app.route('/scc/param/delete/<id>')
def scc_param_delete(id):
    updates = sccParam.deleteOne(id)
    return redirect(url_for('setting_form', tab='scc'))            

@app.route('/scc/config/add', methods=['POST'])
def scc_config_post():
    import random, string
    config_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(5)])
    scc_id = request.form.get('scc_id')
    name = request.form.get('name')
    inserts = sccConfig.insert(config_id,scc_id,name)
    getParam = sccParam.selectBySCC(scc_id)
    if len(getParam) > 0:
       for i in range(len(getParam)):
           value_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
           param_id = getParam[i][0]
           sccValue.insert(value_id, config_id, param_id, "N/A")
    return redirect(url_for('setting_form', tab='scc'))

@app.route('/scc/config/update/<id>', methods=['POST'])
def scc_config_update(id):
    import random, string
    scc_id = request.form.get('scc_id')
    name = request.form.get('name')
    getConfig = sccConfig.selectById(id)
    if len(getConfig) > 0:
       for i in getConfig:
           scc_id_last = i[1]
       if scc_id != scc_id_last:
          sccValue.deleteByConfig(id)
          getParam = sccParam.selectBySCC(scc_id)
          if len(getParam) > 0:
             for x in range(len(getParam)):
                 value_id = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
                 param_id = getParam[x][0]
                 sccValue.insert(value_id, id, param_id, "N/A")
    updates = sccConfig.update(scc_id,name,id)
    return redirect(url_for('setting_form', tab='scc'))

@app.route('/scc/config/delete/<id>')
def scc_config_delete(id):
    updates = sccConfig.deleteOne(id)
    return redirect(url_for('setting_form', tab='scc')) 

@app.route('/scc/config/value/update/<id>', methods=['POST'])
def scc_config__value_update(id):
    value = request.form.get('value')
    updates = sccValue.updateValue(value, id)
    return redirect(url_for('setting_form', tab='scc'))

@app.route('/log/ibms', methods=['GET','POST'])
def log_ibms():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    get_time = times.now()
    date1 = get_time.strftime("%Y-%m-01")
    time1 = '00:00'
    date2 = get_time.strftime("%Y-%m-%d")
    time2 = get_time.strftime("%H:%M")
    if request.method == 'POST':
       date1 = request.form.get('date1')
       time1 = request.form.get('time1')
       date2 = request.form.get('date2')
       time2 = request.form.get('time2')
    datetime1 = date1 + ' ' + time1
    datetime2 = date2 + ' ' + time2
    if datetime1 == ' ' and datetime2 == ' ':
       fetch = logIBMS.selectAll()
    else:
       fetch = logIBMS.selectByTime(datetime1,datetime2)
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('log_ibms.html', rule=rule, fetch=fetch, date1=date1, time1=time1, date2=date2, time2=time2,
                           project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node
                           , state=state, username=username)
        
@app.route('/log/ibms/delete', methods=['POST'])
def log_ibms_deletes():
    datetime1 = request.form.get('datetime1')
    datetime2 = request.form.get('datetime2')
    if datetime1 == ' ' and datetime2 == ' ':
       deletes = logIBMS.deleteAll()
    else:
       deletes = logIBMS.deleteByTime(datetime1,datetime2)
    return redirect(url_for('log_ibms'))  

@app.route('/log/ibms/delete/<id>')
def log_ibms_delete(id):
    delete = logIBMS.deleteOne(id)
    return redirect(url_for('log_ibms'))
    
@app.route('/log/ibms/download', methods=['POST'])
def log_ibms_download():
    datetimes1 = request.form.get('datetimes1')
    datetimes2 = request.form.get('datetimes2')
    if datetimes1 == ' ' and datetimes2 == ' ':
       fetch = logIBMS.selectAll()
    else:
       fetch = logIBMS.selectByTime(datetimes1,datetimes2)
    datas = []
    header = ['timestamp','mcbBSPVoltage','loadBSPCurrent','lvdBSPVoltage','pvVoltage','battVoltage','chargingCurrent','forwardPower','returnLoss']
    datas.append(header)
    for row in range(len(fetch)):
        rows = fetch[row]
        data = [rows[9],float(rows[1]),float(rows[2]),float(rows[3]),float(rows[4]),float(rows[5]),float(rows[6]),float(rows[7]),float(rows[8])]
        datas.append(data)
    sheet = pe.Sheet(datas)
    sheets = io.StringIO()
    sheet.save_to_memory("csv", sheets)
    node_id, name, ip, firm_user, firm_pass = getSetting()    
    filename = "IBMS TV Digital Log (" + str(name) + ").csv"
    output = make_response(sheets.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename="+filename
    output.headers["Content-type"] = "text/csv"    
    return output

@app.route('/log/ibms/upload', methods=['POST'])
def log_ibms_upload():
    uploaded_file = request.files['file']
    data = pd.read_csv(uploaded_file)
    for row in range(len(data)):
        mcbBSPVoltage, loadBSPCurrent, lvdBSPVoltage = data['mcbBSPVoltage'][row], data['loadBSPCurrent'][row], data['lvdBSPVoltage'][row]
        vPV, vBatt, aChg = data['pvVoltage'][row], data['battVoltage'][row], data['chargingCurrent'][row]
        forwardPower, returnLoss = data['forwardPower'][row], data['returnLoss'][row]
        timestamp = data['timestamp'][row]
        inserts = logIBMS.insert(float(mcbBSPVoltage), float(loadBSPCurrent), float(lvdBSPVoltage), float(vPV), float(vBatt), float(aChg), float(forwardPower), float(returnLoss), timestamp)
    return redirect(url_for('log_ibms'))

@app.route('/log/send_node', methods=['GET','POST'])
def log_send_node():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    get_time = times.now()
    date1 = get_time.strftime("%Y-%m-01")
    time1 = '00:00'
    date2 = get_time.strftime("%Y-%m-%d")
    time2 = get_time.strftime("%H:%M")
    if request.method == 'POST':
       date1 = request.form.get('date1')
       time1 = request.form.get('time1')
       date2 = request.form.get('date2')
       time2 = request.form.get('time2')
    datetime1 = date1 + ' ' + time1
    datetime2 = date2 + ' ' + time2
    if datetime1 == ' ' and datetime2 == ' ':
       fetch = logSendNode.selectAll()
    else:
       fetch = logSendNode.selectByTime(datetime1,datetime2)
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('log_sendNode.html', rule=rule, fetch=fetch, date1=date1, time1=time1, date2=date2, time2=time2,
                           project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node
                           , state=state, username=username, level=level)

@app.route('/log/send_node/update/<id>', methods=['POST'])
def log_send_node_update(id):
    data = request.form.get('data')
    state = request.form.get('state')
    buffer = request.form.get('buffer')
    timestamp = request.form.get('timestamp')
    updates = logSendNode.updateAll(data,state,buffer,timestamp,id)
    return redirect(url_for('log_send_node'))
        
@app.route('/log/send_node/delete', methods=['POST'])
def log_send_node_deletes():
    datetime1 = request.form.get('datetime1')
    datetime2 = request.form.get('datetime2')
    if datetime1 == ' ' and datetime2 == ' ':
       deletes = logSendNode.deleteAll()
    else:
       deletes = logSendNode.deleteByTime(datetime1,datetime2)
    return redirect(url_for('log_send_node'))  

@app.route('/log/send_node/delete/<id>')
def log_send_node_delete(id):
    delete = logSendNode.deleteOne(id)
    return redirect(url_for('log_send_node'))
    
@app.route('/log/send_node/download', methods=['POST'])
def log_send_node_download():
    datetimes1 = request.form.get('datetimes1')
    datetimes2 = request.form.get('datetimes2')
    if datetimes1 == ' ' and datetimes2 == ' ':
       fetch = logSendNode.selectAll()
    else:
       fetch = logSendNode.selectByTime(datetimes1,datetimes2)
    datas = []
    header = ['data','state','buffer','timestamp']
    datas.append(header)
    for row in range(len(fetch)):
        data = []
        data.append(json.loads(fetch[row][1]))
        data.append(fetch[row][2])
        if int(fetch[row][3]) == 0:
           buffer = "Yes"
        elif int(fetch[row][3]) == 1:
           buffer = "No"
        else:
           buffer = "Done"    
        data.append(buffer)
        data.append(fetch[row][4]) 
        datas.append(data)
    sheet = pe.Sheet(datas)
    sheets = io.StringIO()
    sheet.save_to_memory("csv", sheets)
    node_id, name, ip, firm_user, firm_pass = getSetting()    
    filename = "Monitoring Log (" + str(name) + ").csv"
    output = make_response(sheets.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename="+filename
    output.headers["Content-type"] = "text/csv"    
    return output   

@app.route('/log/send_node/upload', methods=['POST'])
def log_send_node_upload():
    uploaded_file = request.files['file']
    data = pd.read_csv(uploaded_file)
    for row in range(len(data)):
        datas = data['data'][row]
        datas = datas.replace("'","\"")
        buffer = data['buffer'][row]
        state = data['state'][row]
        state = int(state)
        if buffer == 'Yes':
           buffer = 0
        elif buffer == 'No':
           buffer = 1
        else:
           buffer = 2 
        timestamp = data['timestamp'][row]
        inserts = logSendNode.insert(datas,state,buffer,timestamp)
    return redirect(url_for('log_send_node'))

@app.route('/log/buffer_node', methods=['GET','POST'])
def log_buffer_node():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    get_time = times.now()
    date1 = get_time.strftime("%Y-%m-01")
    time1 = '00:00'
    date2 = get_time.strftime("%Y-%m-%d")
    time2 = get_time.strftime("%H:%M")
    if request.method == 'POST':
       date1 = request.form.get('date1')
       time1 = request.form.get('time1')
       date2 = request.form.get('date2')
       time2 = request.form.get('time2')
    datetime1 = date1 + ' ' + time1
    datetime2 = date2 + ' ' + time2
    if datetime1 == ' ' and datetime2 == ' ':
       fetch = logBufferNode.selectAll()
    else:
       fetch = logBufferNode.selectByTime(datetime1,datetime2)
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('log_bufferNode.html', rule=rule, fetch=fetch, date1=date1, time1=time1, date2=date2, time2=time2,
                           project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node
                           , state=state, username=username, level=level)

@app.route('/log/buffer_node/update/<id>', methods=['POST'])
def log_buffer_node_update(id):
    data = request.form.get('data')
    timestamp = request.form.get('timestamp')
    updates = logBufferNode.updateAll(data,timestamp,id)
    return redirect(url_for('log_buffer_node'))
        
@app.route('/log/buffer_node/delete', methods=['POST'])
def log_buffer_node_deletes():
    datetime1 = request.form.get('datetime1')
    datetime2 = request.form.get('datetime2')
    if datetime1 == ' ' and datetime2 == ' ':
       deletes = logBufferNode.deleteAll()
    else:
       deletes = logBufferNode.deleteByTime(datetime1,datetime2)
    return redirect(url_for('log_buffer_node'))  

@app.route('/log/buffer_node/delete/<id>')
def log_buffer_node_delete(id):
    delete = logBufferNode.deleteOne(id)
    return redirect(url_for('log_buffer_node'))
    
@app.route('/log/buffer_node/download', methods=['POST'])
def log_buffer_node_download():
    datetimes1 = request.form.get('datetimes1')
    datetimes2 = request.form.get('datetimes2')
    if datetimes1 == ' ' and datetimes2 == ' ':
       fetch = logBufferNode.selectAll()
    else:
       fetch = logBufferNode.selectByTime(datetimes1,datetimes2)
    datas = []
    header = ['data','timestamp']
    datas.append(header)
    for row in range(len(fetch)):
        data = []
        data.append(json.loads(fetch[row][1]))
        data.append(fetch[row][2])
        datas.append(data)
    sheet = pe.Sheet(datas)
    sheets = io.StringIO()
    sheet.save_to_memory("csv", sheets)
    node_id, name, ip, firm_user, firm_pass = getSetting()    
    filename = "Buffer Log (" + str(name) + ").csv"
    output = make_response(sheets.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename="+filename
    output.headers["Content-type"] = "text/csv"    
    return output   

@app.route('/log/buffer_node/upload', methods=['POST'])
def log_buffer_node_upload():
    uploaded_file = request.files['file']
    data = pd.read_csv(uploaded_file)
    for row in range(len(data)):
        datas = data['data'][row]
        datas = datas.replace("'","\"")
        timestamp = data['timestamp'][row]
        inserts = logBufferNode.insert(datas,timestamp)
    return redirect(url_for('log_buffer_node'))

@app.route('/log/sensor', methods=['GET','POST'])
def log_sensor():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    datetime1 = times.now()
    datetime2 = datetime1 - datetime.timedelta(hours=2)
    date1 = datetime2.strftime("%Y-%m-%d")
    time1 = datetime2.strftime("%H:%M")
    date2 = datetime1.strftime("%Y-%m-%d")
    time2 = datetime1.strftime("%H:%M")
    sensor_id, sensor_name = '', ''
    if request.method == 'POST':
       date1 = request.form.get('date1')
       time1 = request.form.get('time1')
       date2 = request.form.get('date2')
       time2 = request.form.get('time2')
       sensor_id = request.form.get('sensor_id')
    datetime1 = date1 + ' ' + time1
    datetime2 = date2 + ' ' + time2
    if sensor_id == '' and datetime1 == ' ' and datetime2 == ' ':
       fetch = logSensor.selectAll()
    elif sensor_id != '' and datetime1 == ' ' and datetime2 == ' ':
       fetch = logSensor.selectBySensor(sensor_id)
    else:
       fetch = logSensor.selectByTime(sensor_id,datetime1,datetime2)   
    fetch2 = sensor.select()
    getSensor = sensor.selectById(sensor_id)
    if len(getSensor) > 0:
       for x in range(len(getSensor)):
           sensor_name = getSensor[x][4] 
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))
    return render_template('log_sensor.html', rule=rule, fetch=fetch, date1=date1, time1=time1, date2=date2, time2=time2, fetch2=fetch2, sensor_id=sensor_id,
                           project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           state=state, username=username, sensor_name=sensor_name, level=level)

@app.route('/log/sensor/update/<id>', methods=['POST'])
def log_sensor_update(id):
    sensor_id = request.form.get('sensor_id')
    data = request.form.get('data')
    timestamp = request.form.get('timestamp')
    updates = logSensor.updateAll(sensor_id,data,timestamp,id)
    return redirect(url_for('log_sensor'))

@app.route('/log/sensor/delete', methods=['POST'])
def log_sensor_deletes():
    datetime1 = request.form.get('datetime1')
    datetime2 = request.form.get('datetime2')
    sensor_id = request.form.get('sensor_id')
    if sensor_id == '' and datetime1 == ' ' and datetime2 == ' ':
       deletes = logSensor.deleteAll()
    elif sensor_id != '' and datetime1 == ' ' and datetime2 == ' ':
       deletes = logSensor.deleteByNode(sensor_id)
    else:
       deletes = logSensor.deleteByTime(sensor_id,datetime1,datetime2)
    return redirect(url_for('log_sensor'))  

@app.route('/log/sensor/delete/<id>')
def log_sensor_delete(id):
    delete = logSensor.deleteOne(id)
    return redirect(url_for('log_sensor'))

@app.route('/log/sensor/download', methods=['POST'])
def log_sensor_download():
    node_id, name, ip, firm_user, firm_pass = getSetting()
    datetimes1 = request.form.get('datetimes1')
    datetimes2 = request.form.get('datetimes2')
    sensor_id = request.form.get('sensor_id')
    if sensor_id == '' and datetimes1 == ' ' and datetimes2 == ' ':
       fetch = logBuffer.selectAll()
    elif sensor_id != '' and datetimes1 == ' ' and datetimes2 == ' ':
       fetch = logSensor.selectBySensor(sensor_id)
    else:
       fetch = logSensor.selectByTime(sensor_id,datetimes1,datetimes2)
    datas = []
    header = ['sensor_id','data','timestamp']
    datas.append(header)
    for row in range(len(fetch)):
        data = []
        id = fetch[row][1]
        get = sensor.selectById(id)
        for i in get:
            sensor_id = i[1]
        data.append(sensor_id)
        data_sensor = fetch[row][2]
        data.append(data_sensor)
        data.append(fetch[row][3])
        datas.append(data)
    sheet = pe.Sheet(datas)
    sheets = io.StringIO()
    sheet.save_to_memory("csv", sheets)
    node_id, name, ip, firm_user, firm_pass = getSetting()    
    filename = "Sensor Log (" + str(name) + ").csv"
    output = make_response(sheets.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename="+filename
    output.headers["Content-type"] = "text/csv"    
    return output  

@app.route('/log/sensor/upload', methods=['POST'])
def log_sensor_upload():
    uploaded_file = request.files['file']
    data = pd.read_csv(uploaded_file)
    for row in range(len(data)):
        sensor_id = data['sensor_id'][row]
        get = sensor.selectOne(sensor_id)
        for i in get:
            id = i[0]
        id = int(id)   
        print(id, '-', sensor_id) 
        data_sensor = data['data'][row]
        data_sensor = str(data_sensor)
        timestamp = data['timestamp'][row]
        inserts = logSensor.insert(id,data_sensor,timestamp)
    return redirect(url_for('log_sensor'))

@app.route('/log/notif', methods=['GET','POST'])
def log_notif():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    get_time = times.now()
    date1 = get_time.strftime("%Y-%m-01")
    time1 = '00:00'
    date2 = get_time.strftime("%Y-%m-%d")
    time2 = get_time.strftime("%H:%M")
    if request.method == 'POST':
       date1 = request.form.get('date1')
       time1 = request.form.get('time1')
       date2 = request.form.get('date2')
       time2 = request.form.get('time2')
    datetime1 = date1 + ' ' + time1
    datetime2 = date2 + ' ' + time2
    if datetime1 == ' ' and datetime2 == ' ':
       fetch = logNotif.selectAll()
    else:
       fetch = logNotif.selectByTime(datetime1,datetime2)
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('log_notif.html', rule=rule, fetch=fetch, date1=date1, time1=time1, date2=date2, time2=time2,
                           project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node
                           , state=state, username=username, level=level)

@app.route('/log/notif/update/<id>', methods=['POST'])
def log_notif_update(id):
    types = request.form.get('type')
    notif = request.form.get('notif')
    subject = request.form.get('subject')
    message = request.form.get('message')
    state = request.form.get('state')
    create_time = request.form.get('create_time')
    send_time = request.form.get('send_time')
    updates = logNotif.updateAll(types,notif,subject,message,state,create_time,send_time,id)
    return redirect(url_for('log_notif'))
        
@app.route('/log/notif/delete', methods=['POST'])
def log_notif_deletes():
    datetime1 = request.form.get('datetime1')
    datetime2 = request.form.get('datetime2')
    if datetime1 == ' ' and datetime2 == ' ':
       deletes = logNotif.deleteAll()
    else:
       deletes = logNotif.deleteByTime(datetime1,datetime2)
    return redirect(url_for('log_notif'))  

@app.route('/log/notif/delete/<id>')
def log_notif_delete(id):
    delete = logNotif.deleteOne(id)
    return redirect(url_for('log_notif'))

@app.route('/log/notif/download', methods=['POST'])
def log_notif_download():
    datetimes1 = request.form.get('datetimes1')
    datetimes2 = request.form.get('datetimes2')
    if datetimes1 == ' ' and datetimes2 == ' ':
       fetch = logNotif.selectAll()
    else:
       fetch = logNotif.selectByTime(datetimes1,datetimes2)
    datas = []
    header = ['type','notif','subject','message','state','create_time','send_time']
    datas.append(header)
    for row in range(len(fetch)):
        data = []
        data.append(fetch[row][1])
        data.append(fetch[row][2])
        data.append(fetch[row][3])
        data.append(fetch[row][4])
        data.append(fetch[row][5])
        data.append(fetch[row][6])
        data.append(fetch[row][7]) 
        datas.append(data)
    sheet = pe.Sheet(datas)
    sheets = io.StringIO()
    sheet.save_to_memory("csv", sheets)
    node_id, name, ip, firm_user, firm_pass = getSetting()    
    filename = "Notificaton Log (Node " + str(name) + ").csv"
    output = make_response(sheets.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename="+filename
    output.headers["Content-type"] = "text/csv"    
    return output

@app.route('/log/notif/upload', methods=['POST'])
def log_notif_upload():
    uploaded_file = request.files['file']
    data = pd.read_csv(uploaded_file)
    for row in range(len(data)):
        types = data['type'][row]
        notif = data['notif'][row]
        subject = data['subject'][row]
        message = data['message'][row]
        state = data['state'][row]
        create_time = data['create_time'][row]
        send_time = data['send_time'][row]
        inserts = logNotif.insertAll(types, notif, subject, message, state, create_time, send_time)
    return redirect(url_for('log_notif'))

@app.route('/calibrate/formula', methods=['GET','POST'])
def calibrate_formula():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    tab, result = '0', '-'
    formula_id, sample_value = '', ''
    formulas = calibrateFormula.select()
    if request.method == 'POST':
       tab = request.form.get('tab')
       if tab == '0':
          test = '21' 
       elif tab == '1':
          formula_id = request.form.get('formula_id')
          sample_value = request.form.get('sample_value') 
          result = subprocess.Popen(["python3", "/home/pi/project/calibrate/check_calibrate.py", "-f", formula_id, "-v", sample_value], stdout=subprocess.PIPE)
          (out, err) = result.communicate()
          result = out.decode('utf-8')
          result = result.split('\n')   
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))   
    return render_template('calibrate_formula.html', project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, state=state, username=username, formulas=formulas, tab=tab, result=result, formula_id=formula_id, sample_value=sample_value, level=level)

@app.route('/calibrate/formula/add', methods=['POST'])
def calibrate_formula_add():
    name = request.form.get('name')
    calibrateFormula.insert(name,0)
    return redirect(url_for('calibrate_formula'))
 
@app.route('/calibrate/formula/update/<id>', methods=['POST'])
def calibrate_formula_update(id):
    name = request.form.get('name')
    calibrateFormula.updateNameByFormula(name,id)
    return redirect(url_for('calibrate_formula'))    

@app.route('/calibrate/formula/delete/<id>', methods=['GET'])
def calibrate_formula_delete(id):
    calibrateFormula.deleteOne(id)
    return redirect(url_for('calibrate_formula'))   

@app.route('/calculate/formula/<id>', methods=['GET'])
def calculate_formula(id):
    result = subprocess.Popen(["python3", "/home/pi/project/calibrate/calculate_calibrate.py", "-f", id], stdout=subprocess.PIPE)
    (out, err) = result.communicate()
    result = out.decode('utf-8')
    result = result.split('\n')
    return redirect(url_for('calibrate_formula')) 

@app.route('/calibrate/sample', methods=['GET','POST'])
def calibrate_sample():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    tab = '0'
    sensor_id, result, formula_id = '', '-', ''
    sensors = groups.select()
    samples = calibrateSample.select()
    formulas = calibrateFormula.select()
    if request.method == 'POST':
       tab = request.form.get('tab')
       if tab == '0':
          sensor_id = request.form.get('sensor')
          service = checkActiveService('sensor' + str(sensor_id))
          if service == 'active':
             result = ['Please stop service sensor' + str(sensor_id) + " first before check the sensor"] 
          else:
             filename = "check_sensor" + sensor_id + ".py"
             result = subprocess.Popen(["python3", "/home/pi/project/sensor/"+filename, "-t", "0"], stdout=subprocess.PIPE)
             (out, err) = result.communicate()
             result = out.decode('utf-8')
             result = result.split('\n')
       elif tab == '1':
          form = request.form.get('form') 
          formula_id = request.form.get('formula_id')
          if form == 'add':
             formula = request.form.get('formula')
             value_sample = request.form.get('value_sample')
             value_reference = request.form.get('value_reference')
             calibrateSample.insert(formula, value_sample, value_reference)
             calculate = calibrateSample.selectByFormula(formula)
             calibrateFormula.updateSampleByFormula(len(calculate),formula)
             subprocess.Popen(["python3", "/home/pi/project/calibrate/calculate_calibrate.py", "-f", formula], stdout=subprocess.PIPE)
          elif form == 'delete':
             sample_id = request.form.get('sample_id')
             formula = request.form.get('formula')
             calibrateSample.deleteOne(sample_id) 
             calculate = calibrateSample.selectByFormula(formula)
             calibrateFormula.updateSampleByFormula(len(calculate),formula)
             subprocess.Popen(["python3", "/home/pi/project/calibrate/calculate_calibrate.py", "-f", formula], stdout=subprocess.PIPE) 
          elif form == 'update':
             sample_id = request.form.get('sample_id')
             formula = request.form.get('formula_new')
             formula_last = request.form.get('formula_last')
             value_sample = request.form.get('value_sample')
             value_reference = request.form.get('value_reference')
             calibrateSample.update(formula,value_sample,value_reference,sample_id)
             calculate = calibrateSample.selectByFormula(formula)
             calibrateFormula.updateSampleByFormula(len(calculate),formula)
             calculate2 = calibrateSample.selectByFormula(formula_last)
             calibrateFormula.updateSampleByFormula(len(calculate2),formula_last)    
             subprocess.Popen(["python3", "/home/pi/project/calibrate/calculate_calibrate.py", "-f", formula], stdout=subprocess.PIPE)
             subprocess.Popen(["python3", "/home/pi/project/calibrate/calculate_calibrate.py", "-f", formula_last], stdout=subprocess.PIPE)
          if formula_id == "":
             samples = calibrateSample.select()
          else:
             samples = calibrateSample.selectByFormula(formula_id)            
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))   
    return render_template('calibrate_sample.html', sensors=sensors, project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, sensor_id=sensor_id, result=result, state=state, username=username, formulas=formulas, tab=tab, formula_id=formula_id, samples=samples, level=level)

@app.route('/check/sensor', methods=['GET','POST'])
def check_sensor():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    sensor_id = ''    
    result = '-'
    sensors = groups.select()
    if request.method == 'POST':
       sensor_id = request.form.get('sensor')
       service = checkActiveService('sensor' + str(sensor_id))
       if service == 'active':
          result = ['Please stop service sensor' + str(sensor_id) + " first before check the sensor"] 
       else:
          filename = "check_sensor" + sensor_id + ".py"
          result = subprocess.Popen(["python3", "/home/pi/project/sensor/"+filename, "-t", "1"], stdout=subprocess.PIPE)
          (out, err) = result.communicate()
          result = out.decode('utf-8')
          result = result.split('\n')
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))   
    return render_template('check_sensor.html', sensors=sensors, project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, sensor_id=sensor_id, result=result, state=state, username=username, level=level)

@app.route('/check/send', methods=['GET','POST'])
def check_send():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    tipe = ''
    result = '-'
    if request.method == 'POST':
       tipe = request.form.get('tipe')
       if int(project_protocol) == 1:
          protocol = "http"
       elif int(project_protocol) == 2:
          protocol = "mqtt"
       elif int(project_protocol) == 3:
          protocol = "snmp" 
       if tipe == 'node':
          filename = "/home/pi/project/node/check_" + protocol + ".py"
       elif tipe == 'gateway':
          filename = "/home/pi/project/gateway/check_send.py"
       result = subprocess.Popen(["python3", filename], stdout=subprocess.PIPE)
       (out, err) = result.communicate()
       result = out.decode('utf-8')
       result = result.split('\n')
       if result[0] == '':
          result = '-'
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('check_send.html', project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, result=result, tipe=tipe, state=state, username=username, level=level)

@app.route('/check/oid', methods=['GET','POST'])
def check_oid():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    check = ''
    result = '-'
    list_sensor = sensor.select()
    if request.method == 'POST':
       check = request.form.get('sensor')
       if check == "":
          result = "Please Select the Sensor" 
       else:
          sensor_data = sensor.selectById(check)
          for i in sensor_data:
              group_id = i[2]   
          result = subprocess.Popen(["python3", "../node/check_oid.py", "-i", check, "-g", str(group_id)], stdout=subprocess.PIPE)
          (out, err) = result.communicate()
          result = out.decode('utf-8')
          result = result.split('\n')
          #result.pop(len(result)-1)
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('check_oid.html', project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, result=result, check=check, state=state, username=username, list_sensor=list_sensor, level=level)

@app.route('/display', methods=['GET','POST'])
def display():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    result = '-'
    import time
    path = "/home/pi/project/display/"
    files = os.path.exists(path + "display.tft")
    if request.method == 'POST':
       upload_type = request.form.get('upload')
       if upload_type == 'external': 
          uploaded_file = request.files['file']
          filename = secure_filename(uploaded_file.filename)
       enable = checkEnableService('connex_display')
       if enable == 'enabled':
          os.system('systemctl disable connex_display') 
          result = ['Display service detected enable, system already disable the display service.', 'Please reboot device before upload the file']
       else:    
          service = checkActiveService('connex_display')
          if service == 'active':
             result = ['Display service detected active, system already stop the display service.', 'Please reboot device before upload the file']
             os.system('service connex_display stop') 
          else:
             if upload_type == 'external':
                uploaded_file.save(os.path.join(path + "display_new.tft"))
                script = 'nextion-fw-upload /dev/ttyS0 ' + path + 'display_new.tft -b 115200 -ub 115200'
             else:
                script = 'nextion-fw-upload /dev/ttyS0 ' + path + 'display.tft -b 115200 -ub 115200'
             code = os.system(script)
             if int(code) == 0:
                if upload_type == 'external':
                   os.system("rm " + path + "display.tft")
                   os.system("mv " + path + "display_new.tft " + path + "display.tft")
                result = ['Success Upload Display File']     
             else:
                if upload_type == 'external': 
                   os.system("rm " + path + "display_new.tft") 
                result = ['Error Upload Display File']    
    if files == True:
       last = time.ctime(os.path.getmtime(path + "display.tft"))
    else:
       last = "-" 
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('display.html', project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, state=state, username=username, result=result, last=last, files=files, level=level)

@app.route('/system/service')
def service_form():
    id, username, state, level = checkSession()
    rule = str(request.url_rule)
    project_name, project_port, project_gateway, project_node, project_protocol = getData()
    services = system.select()
    if int(state) == 0:
       flash('Please Login to Access the Page')  
       return redirect(url_for('login'))      
    return render_template('system_service.html', project_name=project_name, project_port=project_port, project_gateway=project_gateway, project_node=project_node,
                           rule=rule, state=state, username=username, services=services, level=level)

@app.route('/service/enable/<name>')
def service_enable(name): 
    os.system("sudo systemctl enable " + name)
    return redirect(url_for('service_form'))

@app.route('/service/disable/<name>')
def service_disable(name): 
    os.system("sudo systemctl disable " + name)
    return redirect(url_for('service_form'))

@app.route('/service/stop/<name>')
def service_stop(name): 
    os.system("sudo service " + name + " stop")
    return redirect(url_for('service_form'))

@app.route('/service/start/<name>')
def service_start(name): 
    os.system("sudo service " + name + " start")
    return redirect(url_for('service_form'))

@app.route('/do/reboot')
def do_reboot():
    os.system("sudo reboot")
    return redirect('/')

#@app.errorhandler(Exception)
#def handle_exception(e):
#    id, username, state, level = checkSession()
#    rule = str(request.url_rule)
#    error = e
#    return render_template('error.html', rule=rule, username=username, state=state, error=error)      
    
if __name__ == '__main__':
   app.run(host='0.0.0.0', port=project_port, debug=True)
