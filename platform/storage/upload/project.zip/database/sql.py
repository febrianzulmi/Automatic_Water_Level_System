import mysql.connector, json, sys
sys.path.append('../../library')
from SynapsisLibrary import *

def openDB():
    with open('../database/db.json', 'r') as f:
        db = json.load(f)
        host = db['host']
        database = db['database']
        username = db['username']
        password = db['password']
    f.close()
    return host, database, username, password

host, database, username, password = openDB()

class mydb():
    global host, database, username, password

    def mysql_connect():
        connect = sql.connect(host, database, username, password)
        return connect

    def mysql_cursor(mysql_connect):
        return sql.cursor(mysql_connect)

class setting():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM setting where id = 1"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall 

    def insert(node_id,name,ip,firm_user,firm_pass,mon,sync,scc_id,log,notif):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO setting (id,id_device,name,ip,user,pass,monitoring,sync,scc_id,log,notif) VALUES (1, %s, %s, %s, %s, %s, %s, %s, %s, %s. %s)"
        value = (node_id,name,ip,firm_user,firm_pass,mon,sync,scc_id,log,notif)
        action = sql.execute(connection, query, value)
        return action

    def update(node_id,name,ip,firm_user,firm_pass,mon,sync,scc_id,log,notif):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE setting set id_device=%s, name=%s, ip=%s, user=%s, pass=%s, monitoring=%s, sync=%s, scc_id=%s, log=%s, notif=%s where id = 1"
        value = (node_id,name,ip,firm_user,firm_pass,mon,sync,scc_id,log,notif)
        action = sql.execute(connection, query, value)
        return action
    
    def updateName(name):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE setting set name=%s where id = 1"
        value = (name,)
        action = sql.execute(connection, query, value)
        return action 
        
class attributes():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM attributes"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def selectOne(name):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM attributes where name = %s"
        value = (name,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
        
    def insert(name,value):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO attributes (name,value) VALUES (%s, %s)"
        value = (name,value)
        action = sql.execute(connection, query, value)
        return action
        
    def update(name,value,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE attributes set name=%s, value=%s WHERE id=%s"
        value = (name,value,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM attributes WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action

class intervals():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM intervals"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def selectOne(name):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM intervals where name = %s"
        value = (name,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
        
    def insert(name,intervals,unit):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO intervals (name,intervals,unit) VALUES (%s, %s, %s)"
        value = (name,intervals,unit)
        action = sql.execute(connection, query, value)
        return action
        
    def update(name,intervals,unit,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE intervals set name=%s, intervals=%s, unit=%s WHERE id=%s"
        value = (name,intervals,unit,id)
        action = sql.execute(connection, query, value)
        return action
    
    def updateByName(intervals,unit,name):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE intervals set intervals=%s, unit=%s WHERE name=%s"
        value = (intervals,unit,name)
        action = sql.execute(connection, query, value)
        return action        
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM intervals WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action
        
class gateway():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM gateway where id = 1"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def insert(values):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO gateway (id, value) VALUES (1, %s)"
        value = (values,)
        action = sql.execute(connection, query, value)
        return action
        
    def update(values):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE gateway set value=%s where id = 1"
        value = (values,)
        action = sql.execute(connection, query, value)
        return action
        
class sensor():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT sensor.*, sensor_group.* FROM sensor join sensor_group on sensor.group_id=sensor_group.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectByGroupFull(group_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT sensor.*, sensor_group.* FROM sensor join sensor_group on sensor.group_id=sensor_group.id where sensor.group_id=%s"
        value = (group_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall    
    
    def selectOne(sensor_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor where sensor_id = %s"
        value = (sensor_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectValue(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT value, timestamp FROM sensor where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall    
    
    def selectById(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall    
    
    def selectCalibrateById(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT calibrate, formula FROM sensor where id=%s"
        value=(id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
            
    def selectByGroup(id_group):
        connection = sql.connect(host, database, username, password)
        query = "SELECT id, sensor_id, name, oid_tipe FROM sensor where group_id=%s"
        value=(id_group,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
            
    def insert(sensor_id,oid,group_id,name,calibrate,formula,oid_tipe,monitor,log):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO sensor (sensor_id,oid,group_id,name,calibrate,formula,oid_tipe,monitor,log) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        value = (sensor_id,oid,group_id,name,calibrate,formula,oid_tipe,monitor,log)
        action = sql.execute(connection, query, value)
        return action
        
    def update(sensor_id,oid,group_id,name,calibrate,formula,oid_tipe,monitor,log,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE sensor set sensor_id=%s, oid=%s, group_id=%s, name=%s, calibrate=%s, formula=%s, oid_tipe=%s, monitor=%s, log=%s WHERE id=%s"
        value = (sensor_id,oid,group_id,name,calibrate,formula,oid_tipe,monitor,log,id)
        action = sql.execute(connection, query, value)
        return action
    
    def updateParam(name, notif, sensor_max, sensor_min, unit, sensor_id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE sensor set name=%s, notif=%s, max=%s, min=%s, unit=%s WHERE sensor_id=%s"
        value = (name, notif, sensor_max, sensor_min, unit, sensor_id)
        action = sql.execute(connection, query, value)
        return action  
        
    def updateValue(value,timestamp,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE sensor set value=%s, timestamp=%s WHERE id=%s"
        value = (value,timestamp,id)
        action = sql.execute(connection, query, value)
        return action   
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM sensor WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action

class sccType():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_type"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def selectById(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_type where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall 
        
    def insert(scc_id, name, sensor):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO scc_type (id, name, sensor) VALUES (%s, %s, %s)"
        value = (scc_id, name, sensor)
        action = sql.execute(connection, query, value)
        return action
        
    def update(name, sensor, id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE scc_type set name=%s, sensor=%s WHERE id=%s"
        value = (name, sensor, id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM scc_type WHERE id=%s"
        value = (id,)
        action = sql.execute(connection, query, value)
        return action               

class sccParam():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT scc_param.*, scc_type.* FROM scc_param join scc_type on scc_param.scc_id=scc_type.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectById(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_param where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall 
        
    def selectBySCC(scc_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_param where scc_id = %s"
        value = (scc_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall    
    
    def insert(id,scc_id,name,parameter):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO scc_param (id,scc_id,name,parameter) VALUES (%s, %s, %s, %s)"
        value = (id,scc_id,name,parameter)
        action = sql.execute(connection, query, value)
        return action
        
    def update(scc_id,name,parameter,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE scc_param set scc_id=%s, name=%s, parameter=%s WHERE id=%s"
        value = (scc_id,name,parameter,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM scc_param WHERE id=%s"
        value = (id,)
        action = sql.execute(connection, query, value)
        return action                                

class sccConfig():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT scc_config.*, scc_type.* FROM scc_config join scc_type on scc_config.scc_id = scc_type.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectById(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_config where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall 
    
    def selectBySCC(scc_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_config where scc_id = %s"
        value = (scc_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall     
        
    def insert(config_id, scc_id, name):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO scc_config (id, scc_id, name) VALUES (%s, %s, %s)"
        value = (config_id, scc_id, name)
        action = sql.execute(connection, query, value)
        return action
        
    def update(scc_id,name,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE scc_config set scc_id=%s, name=%s WHERE id=%s"
        value = (scc_id,name,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM scc_config WHERE id=%s"
        value = (id,)
        action = sql.execute(connection, query, value)
        return action 

class sccValue():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT scc_value.*, scc_config.*, scc_param.* FROM `scc_value` join scc_config on scc_value.config_id=scc_config.id join scc_param on scc_value.param_id=scc_param.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectByConfigParam(config_id, param_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_value where config_id = %s and param_id = %s"
        value = (config_id,param_id)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall 
        
    def selectByConfig(config_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM scc_value where config_id = %s"
        value = (config_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall  
        
    def insert(value_id, config_id, param_id, value):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO scc_value (id, config_id, param_id, value) VALUES (%s, %s, %s, %s)"
        value = (value_id, config_id, param_id, value)
        action = sql.execute(connection, query, value)
        return action
        
    def updateValue(value, id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE scc_value set value=%s WHERE id=%s"
        value = (value,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteByConfig(config_id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM scc_value WHERE config_id=%s"
        value = (config_id,)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteByConfigParam(config_id, param_id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM scc_value WHERE config_id=%s and param_id=%s"
        value = (config_id,param_id)
        action = sql.execute(connection, query, value)
        return action      
    
    def deleteOne(id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM scc_value WHERE id=%s"
        value = (id,)
        action = sql.execute(connection, query, value)
        return action 

class calibrateFormula():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM calibrate_formula"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectById(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM calibrate_formula where id=%s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall     
    
    def insert(name,sample):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO calibrate_formula (name,sample) VALUES (%s,%s)"
        value = (name,sample)
        action = sql.execute(connection, query, value)
        return action
    
    def updateNameByFormula(name,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE calibrate_formula set name=%s WHERE id=%s"
        value = (name,id)
        action = sql.execute(connection, query, value)
        return action  
    
    def updateSampleByFormula(sample,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE calibrate_formula set sample=%s WHERE id=%s"
        value = (sample,id)
        action = sql.execute(connection, query, value)
        return action  
    
    def updateCoefByFormula(koef_a,koef_b,datetime,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE calibrate_formula set koef_a=%s, koef_b=%s, calculate_time=%s WHERE id=%s"
        value = (koef_a,koef_b,datetime,id)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM calibrate_formula WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action            

class calibrateSample():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT calibrate_sample.*, calibrate_formula.* FROM calibrate_sample join calibrate_formula on calibrate_sample.formula_id=calibrate_formula.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectByFormula(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT calibrate_sample.*, calibrate_formula.* FROM calibrate_sample join calibrate_formula on calibrate_sample.formula_id=calibrate_formula.id where calibrate_sample.formula_id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall    
    
    def insert(formula,value_sample,value_reference):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO calibrate_sample(formula_id,value_sample,value_reference) VALUES (%s,%s,%s)"
        value = (formula,value_sample,value_reference)
        action = sql.execute(connection, query, value)
        return action 
    
    def update(formula_id,sample,reference,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE calibrate_sample set formula_id=%s, value_sample=%s, value_reference=%s WHERE id=%s"
        value = (formula_id,sample,reference,id)
        action = sql.execute(connection, query, value)
        return action      
        
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM calibrate_sample WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action            

class paramList():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT sensor_paramList.*, sensor.* FROM sensor_paramList join sensor on sensor_paramList.sensor_id=sensor.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectByGroupFull(group_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT sensor_paramList.*, sensor.* FROM sensor_paramList join sensor on sensor_paramList.sensor_id=sensor.id where sensor.group_id=%s"
        value = (group_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectBySensorParameter(id,parameter):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor_paramList where sensor_id = %s and parameter=%s"
        value = (id,parameter)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall 
    
    def insert(sensor_id,name,parameter,value):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO sensor_paramList (sensor_id,name,parameter,value) VALUES (%s, %s, %s, %s)"
        value = (sensor_id,name,parameter,value)
        action = sql.execute(connection, query, value)
        return action
        
    def update(sensor_id,name,parameter,value,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE sensor_paramList set sensor_id=%s, name=%s, parameter=%s, value=%s WHERE id=%s"
        value = (sensor_id,name,parameter,value,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM sensor_paramList WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action    

class params():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT sensor_param.*, sensor_group.* FROM sensor_param join sensor_group on sensor_param.group_id=sensor_group.id"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectByGroupFull(group_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT sensor_param.*, sensor_group.* FROM sensor_param join sensor_group on sensor_param.group_id=sensor_group.id where sensor_param.group_id=%s"
        value = (group_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectOne(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor_param where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectByGroupParameter(id,parameter):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor_param where group_id = %s and parameter=%s"
        value = (id,parameter)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall     
    
    def insert(group_id,name,parameter,value):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO sensor_param (group_id,name,parameter,value) VALUES (%s, %s, %s, %s)"
        value = (group_id,name,parameter,value)
        action = sql.execute(connection, query, value)
        return action
        
    def update(group_id,name,parameter,value,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE sensor_param set group_id=%s, name=%s, parameter=%s, value=%s WHERE id=%s"
        value = (group_id,name,parameter,value,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM sensor_param WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action

class groups():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor_group"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectOne(id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor_group where id = %s"
        value = (id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectByName(name):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM sensor_group where name = %s"
        value = (name,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
            
    def insert(name,intervals,unit,frekuensi,service_id):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO sensor_group (name,intervals,unit,frekuensi,service_id) VALUES (%s, %s, %s, %s, %s)"
        value = (name,intervals,unit,frekuensi,service_id)
        action = sql.execute(connection, query, value)
        return action
        
    def update(name,intervals,unit,frekuensi,service_id,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE sensor_group set name=%s, intervals=%s, unit=%s, frekuensi=%s, service_id=%s WHERE id=%s"
        value = (name,intervals,unit,frekuensi,service_id,id)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM sensor_group WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action

class logIBMS():
    def selectAll():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_ibms ORDER by timestamp DESC"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def selectByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_ibms WHERE timestamp BETWEEN %s AND %s ORDER by timestamp DESC"
        value = (datetime1,datetime2)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall

    def insert(mcbBSP, aBSP, vBSP, vPV, vBatt, aChg, forwardPower, returnLoss, timestamp):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO log_ibms (mcbBSPVoltage, loadBSPCurrent, lvdBSPVoltage, pvVoltage, battVoltage, chargingCurrent, forwardPower, returnLoss, timestamp) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        value = (mcbBSP, aBSP, vBSP, vPV, vBatt, aChg, forwardPower, returnLoss, timestamp)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_ibms WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_ibms WHERE timestamp BETWEEN %s AND %s"
        value = (datetime1,datetime2) 
        action = sql.execute(connection, query, value)
        return action
    
    def deleteAll():
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_ibms"
        action = sql.execute(connection, query)
        connection = sql.connect(host, database, username, password)
        query = "TRUNCATE TABLE log_ibms"
        action = sql.executeOnly(connection, query)
        return action
        
class logSendNode():
    def selectAll():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_sendNode ORDER by timestamp DESC"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def selectByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_sendNode WHERE timestamp BETWEEN %s AND %s ORDER by timestamp DESC"
        value = (datetime1,datetime2)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall

    def insert(data,state,buffer,timestamp,tipe):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO log_sendNode (data,state,buffer,timestamp,tipe) VALUES (%s, %s, %s, %s, %s)"
        value = (data,state,buffer,timestamp,tipe)
        action = sql.execute(connection, query, value)
        return action
    
    def updateAll(data,state,buffer,timestamp,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE log_sendNode set data=%s, state=%s, buffer=%s, timestamp=%s WHERE id=%s"
        value = (data,state,buffer,timestamp,id)
        action = sql.execute(connection, query, value)
        return action
    
    def updateLog(data,timestamp):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE log_sendNode set buffer=2 WHERE data=%s AND timestamp=%s"
        value = (data,timestamp)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_sendNode WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_sendNode WHERE timestamp BETWEEN %s AND %s"
        value = (datetime1,datetime2) 
        action = sql.execute(connection, query, value)
        return action
    
    def deleteAll():
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_sendNode"
        action = sql.execute(connection, query)
        connection = sql.connect(host, database, username, password)
        query = "TRUNCATE TABLE log_sendNode"
        action = sql.executeOnly(connection, query)
        return action

class logBufferNode():
    def selectAll():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_bufferNode ORDER by timestamp DESC"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectBuffer():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_bufferNode"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall    
    
    def selectByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_bufferNode WHERE timestamp BETWEEN %s AND %s ORDER by timestamp DESC"
        value = (datetime1,datetime2)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall

    def insert(data,timestamp):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO log_bufferNode (data,timestamp) VALUES (%s, %s)"
        value = (data,timestamp)
        action = sql.execute(connection, query, value)
        return action
    
    def updateAll(data,timestamp,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE log_bufferNode set data=%s, timestamp=%s WHERE id=%s"
        value = (data,timestamp,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_bufferNode WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_bufferNode WHERE timestamp BETWEEN %s AND %s"
        value = (datetime1,datetime2) 
        action = sql.execute(connection, query, value)
        return action
    
    def deleteAll():
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_bufferNode"
        action = sql.execute(connection, query)
        connection = sql.connect(host, database, username, password)
        query = "TRUNCATE TABLE log_bufferNode"
        action = sql.executeOnly(connection, query)
        return action

class logSensor():
    def selectAll():
        connection = sql.connect(host, database, username, password)
        query = "SELECT log_sensor.*, sensor.sensor_id, sensor.name FROM log_sensor join sensor on log_sensor.sensor_id=sensor.id ORDER BY timestamp DESC"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectOne(sensor_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_sensor where sensor_id=%s ORDER BY timestamp DESC"
        value=(sensor_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
        
    def selectLastOne(sensor_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_sensor where sensor_id=%s ORDER BY timestamp DESC LIMIT 1"
        value=(sensor_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectBySensor(sensor_id):
        connection = sql.connect(host, database, username, password)
        query = "SELECT log_sensor.*, sensor.sensor_id, sensor.name FROM log_sensor join sensor on sensor.id=log_sensor.sensor_id WHERE log_sensor.sensor_id=%s ORDER by log_sensor.timestamp DESC"
        value = (sensor_id,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectByTime(sensor_id,datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        if sensor_id == '':
           query = "SELECT log_sensor.*, sensor.sensor_id, sensor.name FROM log_sensor join sensor on sensor.id=log_sensor.sensor_id WHERE log_sensor.timestamp BETWEEN %s AND %s ORDER by log_sensor.timestamp DESC"
           value = (datetime1,datetime2)
        else:
           query = "SELECT log_sensor.*, sensor.sensor_id, sensor.name FROM log_sensor join sensor on sensor.id=log_sensor.sensor_id  WHERE log_sensor.sensor_id=%s AND log_sensor.timestamp BETWEEN %s AND %s ORDER by log_sensor.timestamp DESC"
           value = (sensor_id,datetime1,datetime2)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall

    def insert(sensor_id,data,timestamp):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO log_sensor (sensor_id,data,timestamp) VALUES (%s, %s, %s)"
        value = (sensor_id,data,timestamp)
        action = sql.execute(connection, query, value)
        return action

    def updateAll(sensor_id, data, timestamp,id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE log_sensor set sensor_id=%s, data=%s, timestamp=%s WHERE id=%s"
        value = (sensor_id, data, timestamp,id)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_sensor WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteBySensor(sensor_id):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_sensor WHERE sensor_id=%s"
        value = (sensor_id,)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteByTime(sensor_id,datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        if sensor_id == '':
           query = "DELETE FROM log_sensor WHERE timestamp BETWEEN %s AND %s"
           value = (datetime1,datetime2) 
        else:
           query = "DELETE FROM log_sensor WHERE sensor_id=%s AND timestamp BETWEEN %s AND %s"
           value = (sensor_id,datetime1,datetime2)
        action = sql.execute(connection, query, value)
        return action
    
    def deleteAll():
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_sensor"
        action = sql.execute(connection, query)
        connection = sql.connect(host, database, username, password)
        query = "TRUNCATE TABLE log_sensor"
        action = sql.executeOnly(connection, query)
        return action

class logNotif():
    def selectAll():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_notif ORDER BY create_time DESC"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
    
    def selectByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_notif WHERE create_time BETWEEN %s AND %s ORDER by create_time DESC"
        value = (datetime1,datetime2)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
    
    def selectByState():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM log_notif WHERE state != 'Success' ORDER by create_time DESC"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall    
    
    def insertAll(tipe, notif, subject, message, state, create_time, send_time):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO log_notif (type,notif,subject,message,state,create_time,send_time) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        value = (tipe, notif, subject, message, state, create_time, send_time)
        action = sql.execute(connection, query, value)
        return action    
    
    def insert(tipe, notif, subject, message, state, timestamp):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO log_notif (type,notif,subject,message,state,create_time) VALUES (%s, %s, %s, %s, %s, %s)"
        value = (tipe, notif, subject, message, state, timestamp)
        action = sql.execute(connection, query, value)
        return action
    
    def updateAll(tipe, notif, subject, message, state, create_time, send_time, id):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE log_notif set type=%s, notif=%s, subject=%s, message=%s, state=%s, create_time=%s, send_time=%s WHERE id=%s"
        value = (tipe, notif, subject, message, state, create_time, send_time, id)
        action = sql.execute(connection, query, value)
        return action    
    
    def updateNotif(id_log, state, send_time):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE log_notif set state=%s, send_time=%s WHERE id=%s"
        value = (state, send_time,id_log)
        action = sql.execute(connection, query, value)
        return action  
    
    def deleteOne(id_data):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_notif WHERE id=%s"
        value = (id_data,)
        action = sql.execute(connection, query, value)
        return action
        
    def deleteByTime(datetime1,datetime2):
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_notif WHERE create_time BETWEEN %s AND %s"
        value = (datetime1,datetime2) 
        action = sql.execute(connection, query, value)
        return action
    
    def deleteAll():
        connection = sql.connect(host, database, username, password)
        query = "DELETE FROM log_notif"
        action = sql.execute(connection, query)
        connection = sql.connect(host, database, username, password)
        query = "TRUNCATE TABLE log_notif"
        action = sql.executeOnly(connection, query)
        return action

class system():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM system"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def insert(name,service,enable,last_run,since):
        connection = sql.connect(host, database, username, password)
        query = "INSERT INTO system (name,service,enable,last_run,since) VALUES (%s, %s, %s, %s, %s)"
        value = (name,service,enable,last_run,since)
        action = sql.execute(connection, query, value)
        return action
    
    def selectByName(name):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM system where name = %s"
        value = (name,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
        
    def updateStatusByName(state,times,name):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE system set state=%s, last_update=%s WHERE name=%s"
        value = (state,times,name)
        action = sql.execute(connection, query, value)
        return action 
    
    def updateServiceByName(service,enable,last_run,since,name):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE system set service=%s, enable=%s, last_run=%s, since=%s WHERE name=%s"
        value = (service,enable,last_run,since,name)
        action = sql.execute(connection, query, value)
        return action         

class statistic():
    def select():
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM statistic"
        fetchall = sql.selectNoInput(connection, query)
        return fetchall
        
    def selectByName(name):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM statistic where name = %s"
        value = (name,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
        
    def updateValueByName(value,name):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE statistic set value=%s WHERE name=%s"
        value = (value,name)
        action = sql.execute(connection, query, value)
        return action        

class token():        
    def selectByName(name):
        connection = sql.connect(host, database, username, password)
        query = "SELECT * FROM token where name = %s"
        value = (name,)
        fetchall = sql.selectWithInput(connection, query, value)
        return fetchall
        
    def updateValueByName(value,name):
        connection = sql.connect(host, database, username, password)
        query = "UPDATE token set value=%s WHERE name=%s"
        value = (value,name)
        action = sql.execute(connection, query, value)
        return action        
