import requests, json, os, shutil, subprocess, datetime
from sql import *

def getPort():
    try:
       f = open("../../platform/ports.conf","r")
       port = f.read()
       f.close()
       port = port.replace("\n","")
    except:
       port = '80'
    return port

def checkSession():
    port = getPort()
    try:
       sess = requests.get('http://localhost:' + port + '/api/project/session')
       sess = sess.text
       sess = json.loads(sess)
       id = sess['id']
       username = sess['username']
       state = sess['state']
       level = sess['level']
    except Exception as e:
       id = 0
       username = ''
       level = 0
       state = 0
    return id, username, state, level

def getData():
    port = getPort()
    try:
       project = requests.get('http://localhost:' + port + '/api/project')
       project = project.text
       project = json.loads(project)
       name = project['name']
       port = project['port']
       gateway = project['gateway']
       node = project['node']
       protocol = project['protocol']
    except Exception as e:
       print(e)
       name = ''
       port = None
       gateway = 0
       node = 0
       protocol = 0
    return name, port, gateway, node, protocol

def getSetting():
    cek = setting.select()
    if len(cek) > 0:
       for i in cek:
           id_device = i[1]
           name= i[2]
           if id_device == 0:
              id_device = ''
           ip = i[3]
           firm_user = i[4]
           firm_pass = i[5]
    else:	
        id_device = ''
        name = ''
        ip = ''
        firm_pass = ''
        firm_user = ''
    return id_device, name, ip, firm_user, firm_pass

def getConnexSetting():    
    cek = setting.select()
    if len(cek) > 0:
       for i in cek:
           monitoring = i[7]
           sync = i[8]
           log = i[10]
           notif = i[11]
    else:	
        monitoring = ''
        sync = ''
        log = ''
        notif = ''
    return monitoring, sync, log, notif   

def getSCC():
    cek = setting.select()
    scc_id, scc_name = '', ''
    if len(cek) > 0:
       for i in cek:
           scc_id = i[9]
       get_scc = sccType.selectById(scc_id)
       for x in get_scc:
           scc_name = x[1]      
    else:	
       scc_id, scc_name = '', ''
    return scc_id, scc_name  

def checkTokenHTTP():
    def select(name):
        cek = token.selectByName(name)
        if len(cek) > 0:
           for i in cek:
               value = i[2]
        else:
           value = 'N/A'
        return value
    tokens = select("token")
    if tokens == "N/A" or tokens == None or tokens == "":
       token.updateValueByName(0, "state")
       expire = "N/A"
       state = 0
    else:
       expire = select("expire")
       expireTime = expire.replace(" GMT","")
       expireTime = datetime.datetime.strptime(expireTime, "%a, %d %b %Y %H:%M:%S")
       expireTime = expireTime + datetime.timedelta(hours=7)
       nowTime = datetime.datetime.now()
       if nowTime > expireTime:
          state = 0 
       else:
          state = 1          
    return state, tokens, expire      
     
def getTopic(name):
    cek = attributes.selectOne(name)
    if len(cek) > 0:
       for i in cek:
           param = i[2]
    else:
       param = ''
    return param

def getBaseOID(group_id):
    base = params.selectByGroupParameter(group_id, "parent_oid")
    base_oid = 'Undefined'
    for y in base:
        base_oid = y[4]
    return base_oid

def getURL(ip, name):
    cek = attributes.selectOne(name)
    if len(cek) > 0:
       for i in cek:
           param = i[2]
    else:
       param = ''
    if ip == '':
      urls = 'Undefined IP'
    else:
       if param == '':
          urls = 'Undefined Parameter'
       else:
          urls = 'https://'+ str(ip) + str(param)
    return urls
    
def checkURL(url):
    if url == 'Undefined Parameter' or url == 'Undefined IP':
       state = 0
    else:
       state = 1
    return state

def getInterval(name):
    default = 60
    cek = intervals.selectOne(name)
    if len(cek) > 0:
       for i in cek:
           interval = i[2]
           unit = i[3]
       if int(unit) == 1:
          interval = interval 
       elif int(unit) == 2:
          interval = int(interval) * 60
       elif int(unit) == 3:
          interval = int(interval) * 3600
       else:
          interval = default
    else:
       interval = default
    return interval 

def getSensorSetting(group_id):
    try:
      get = groups.selectOne(group_id)
      if len(get) > 0:
         for i in get:
             interval = i[2]
             unit = i[3]
             if unit == 1:
                interval = interval
             elif unit == 2:
                interval = interval * 60
             else:
                interval = interval * 3600
             frekuensi = i[4]
      else:
         interval = 60 #in Seconds
         frekuensi = 1
    except:
      interval = 60 #in Seconds
      frekuensi = 1
    return interval, frekuensi

def getSensorByGroup(group_id):
    id, sensor_id, sensor_name, = [], [], []
    sensors  = sensor.selectByGroup(group_id)
    if len(sensors) > 0:
       for i in range(len(sensors)):
           id.append(sensors[i][0])
           sensor_id.append(sensors[i][1])
           sensor_name.append(sensors[i][2])           
    num_sensor = len(sensors)       
    return id, sensor_id, sensor_name, num_sensor

def getAllSensor():
    id, sensor_id, sensor_name, group_id, sensor_value = [], [], [], [], []
    sensors  = sensor.select()
    if len(sensors) > 0:
       for i in range(len(sensors)):
           id.append(sensors[i][0])
           sensor_id.append(sensors[i][1])
           group_id.append(sensors[i][2])
           sensor_name.append(sensors[i][4])
           value = sensors[i][5]
           if value == None:
              value = '0'
           sensor_value.append(value)   
    num_sensor = len(sensors)       
    return id, sensor_id, sensor_name, group_id, sensor_value, num_sensor

def getParameterGroupSensor(group_id,parameter):
    parameterData = params.selectByGroupParameter(group_id,parameter)
    if len(parameterData) > 0:
       for i in parameterData:
           value = i[4]
    else:
       value = None
    return value

def getParameterListSensor(sensor_id,parameter):
    parameterData = paramList.selectBySensorParameter(sensor_id,parameter)
    if len(parameterData) > 0:
       for i in parameterData:
           value = i[4]
    else:
       value = None
    return value         

def getGatewayHTTP():
    ports = gateway.select()
    for i in ports:
        port = i[1]

def checkDetailService(nama):
    detail =  subprocess.Popen("systemctl status " + nama + " | grep since", shell=True, stdout=subprocess.PIPE)
    (out, err) = detail.communicate()
    detail = out.decode('utf-8')
    detail = detail.replace('\n','')
    search1 = detail.find("since")
    search2 = detail.find("WIB")
    search3 = detail.find("ago")
    last_run = detail[search1+6:search2-1]
    since = detail[search2+5:search3]
    return last_run, since
        
def checkActiveService(nama):
    active =  subprocess.Popen(["systemctl", "is-active",  nama], stdout=subprocess.PIPE)
    (out, err) = active.communicate()
    active = out.decode('utf-8')
    active = active.replace('\n','')
    return active

def checkEnableService(nama):
    enable =  subprocess.Popen(["systemctl", "is-enabled",  nama], stdout=subprocess.PIPE)
    (outs, errs) = enable.communicate()
    enable = outs.decode('utf-8')
    enable = enable.replace('\n','') 
    return enable

def getServiceState(serviceName):
    serviceDatas = system.selectByName(serviceName)
    if len(serviceDatas) > 0:
       for i in serviceDatas:
           service = i[2]
           state = i[4]
           last_update = i[5] 
    else:
       service = checkActiveService(serviceName)
       state, last_udpate = '-', '-'
    return service, state, last_update

def calibrateSensor(id, value):
    calibrate_value, sensor_calibrate = [], []
    for i in range(len(id)):
        get_calibrate = sensor.selectCalibrateById(id[i])
        for x in get_calibrate:
            calibrate = x[0]
            formula = x[1]
        sensor_calibrate.append(calibrate)    
        if str(calibrate) == '0':
           coefA, coefB = 1, 0
           values = value[i]
        elif str(calibrate) == '1':
           get_formula = calibrateFormula.selectById(formula)
           for y in get_formula:
               coefA = float(y[3])
               coefB = float(y[4])
           values = (coefA*value[i]) + coefB
           values = round(values,2)
           if values < 0:
              values = 0.00
        calibrate_value.append(values)       
    return calibrate_value, sensor_calibrate        

def oidWriteFile(oid_file, oid, oid_tipe, oid_value):
    try:
        f = open(str(oid_file), "w")
        f.write("." + str(oid) + ".0")
        f.write("\n")
        f.write(oid_tipe)
        f.write("\n")
        f.write(str(oid_value))
        f.write("\n")
        f.close()
        state = 1
    except Exception as e:
        state = 0
    return state

def createOID():
    def handleValue(oid_type):
        if oid_type == 0:
           values = '0'
        else:
           values = 'N/A'
        return values      
    base = "/home/pi"
    path_snmp =  base + "/project/sensor/oid"
    os.system("sudo rm -r " + path_snmp)
    cek = os.path.exists(path_snmp)
    if cek == False:
       os.system("sudo mkdir " + path_snmp)
    if base != '':
       sensors  = sensor.select()
       if len(sensors) > 0:
          shutil.copy(base + '/platform/storage/snmpd.conf.master', '/etc/snmp/snmpd.conf')
          files = open("/etc/snmp/snmpd.conf", "a")
          files.write("\n")
          for i in range(len(sensors)):
              id = sensors[i][0]
              oid_sensor = sensors[i][3] 
              base_oid = getBaseOID(sensors[i][2])
              oid = base_oid + "." + str(oid_sensor)
              oid_script = path_snmp + "/" + oid + ".sh"
              cek_script = os.path.exists(oid_script)
              if cek_script == False:
                 f = open(oid_script, "w") 
                 f.write("#!/bin/bash\n")
                 f.write("cat /tmp/" + oid)
                 f.close()
              values = sensor.selectById(id)
              if len(values) > 0:
                 for i in values:
                     value = i[5]
                     oid_tipe = i[13]
                 if value == None:
                    value = handleValue(oid_tipe)    
              else:
                 value = '0'
                 oid_tipe = 0
              if oid_tipe == 0:
                 oid_tipe = 'integer'
                 oid_value = int(float(value)*100)
              else:
                 oid_tipe = 'string'
                 oid_value = value
              oid_file = "/tmp/" + str(oid)
              state = oidWriteFile(oid_file, oid, oid_tipe, oid_value)       
              files.write("pass ." + oid + " /bin/sh " + oid_script + "\n")
          files.close()    
          os.system("sudo service snmpd restart")

def updateLog(id, sensor_name, sensor_value, num_sensor, timestamp):
    logData = 0
    for i in range(num_sensor):
        log = sensor.updateValue(sensor_value[i], timestamp, id[i])
        if log == '1':
           logData += 1
    print("Sensor Log : " + str(logData) + " of " + str(num_sensor) + " Sensors Success Log")         
    
def updateOID(id, sensor_name, sensor_value, num_sensor, group_id):
    logOID = 0
    for i in range(num_sensor):
        base_oid = getBaseOID(group_id)
        sensor_data = sensor.selectById(id[i])
        for z in sensor_data:
            last_oid = z[3]
            oid_tipe = z[13]      
        oid = str(base_oid) + "." + str(last_oid)
        oid_file = "/tmp/" + str(oid)
        if oid_tipe == 0:
           oid_tipe = 'integer'
           oid_value = int(float(sensor_value[i])*100)
        else:
           oid_tipe = 'string'
           oid_value = sensor_value[i]     
        state = oidWriteFile(oid_file, oid, oid_tipe, oid_value)
        logOID += state
    print("Sensor OID : " + str(logOID) + " of " + str(num_sensor) + " Sensors Success Update OID")    

class getDataSensor():
    def handleValueType(oid_type):
        if oid_type == 0:
           value = '0'
        else:    
           value = 'N/A'
        return value    
    
    def handleValueService(group_id, oid_type, value):
        serviceName = "sensor" + str(group_id)
        service, state_sensor, last_update = getServiceState(serviceName)
        if service == "active":
           if 'Success' not in state_sensor:
              value = getDataSensor.handleValueType(oid_type)
        else:
           value = getDataSensor.handleValueType(oid_type)
        return value 
                   
    def handleValueDB(value, oid_type):
        if value == None:
           value = getDataSensor.handleValueType(oid_type)
        return value
            
    def all():
        id, sensor_id, sensor_name, group_id, sensor_value, oid_tipe = [], [], [], [], [], []
        sensor_monitor, sensor_log = [], []
        sensors  = sensor.select()
        if len(sensors) > 0:
           for i in range(len(sensors)):
               id.append(sensors[i][0])
               sensor_id.append(sensors[i][1])
               group_id.append(sensors[i][2])
               sensor_name.append(sensors[i][4])
               value = getDataSensor.handleValueDB(sensors[i][5], sensors[i][13])
               value = getDataSensor.handleValueService(sensors[i][2], sensors[i][13], value)               
               sensor_value.append(value)
               oid_tipe.append(sensors[i][13])
               sensor_monitor.append(sensors[i][14])
               sensor_log.append(sensors[i][15])
        dataSensor = {}
        dataSensor['id'], dataSensor['sensor_id'] = id, sensor_id
        dataSensor['sensor_name'], dataSensor['group_id'] = sensor_name, group_id
        dataSensor['sensor_value'], dataSensor['oid_type'] = sensor_value, oid_tipe
        dataSensor['sensor_monitor'], dataSensor['sensor_log'] = sensor_monitor, sensor_log
        dataSensor['num_sensor'] = len(sensors)         
        return dataSensor        
     
    def priorityMonitor():
        id, sensor_id, sensor_name, sensor_value = [], [], [], []
        dataSensor = getDataSensor.all()
        for i in range(dataSensor['num_sensor']):
            if dataSensor['sensor_monitor'][i] == 1:
               id.append(dataSensor['id'][i])
               sensor_id.append(dataSensor['sensor_id'][i])
               sensor_name.append(dataSensor['sensor_name'][i]) 
               sensor_value.append(dataSensor['sensor_value'][i])
        num_sensor = len(id)       
        return id, sensor_id, sensor_name, sensor_value, num_sensor       
        
    def priorityLog():
        id, sensor_id, sensor_name, sensor_value = [], [], [], []
        dataSensor = getDataSensor.all()
        for i in range(dataSensor['num_sensor']):
            if dataSensor['sensor_log'][i] == 1:
               id.append(dataSensor['id'][i])
               sensor_id.append(dataSensor['sensor_id'][i])
               sensor_name.append(dataSensor['sensor_name'][i]) 
               sensor_value.append(dataSensor['sensor_value'][i])
        num_sensor = len(id)       
        return id, sensor_id, sensor_name, sensor_value, num_sensor
    
    def dailyLog():
        id, sensor_id, sensor_name, sensor_value = [], [], [], []
        dataSensor = getDataSensor.all()
        for i in range(dataSensor['num_sensor']):
            if dataSensor['sensor_log'][i] == 2:
               id.append(dataSensor['id'][i])
               sensor_id.append(dataSensor['sensor_id'][i])
               sensor_name.append(dataSensor['sensor_name'][i]) 
               sensor_value.append(dataSensor['sensor_value'][i])
        num_sensor = len(id)       
        return id, sensor_id, sensor_name, sensor_value, num_sensor
        
    def dailyMonitor():
        id, sensor_id, sensor_name, sensor_value = [], [], [], []
        dataSensor = getDataSensor.all()
        for i in range(dataSensor['num_sensor']):
            if dataSensor['sensor_monitor'][i] == 2:
               id.append(dataSensor['id'][i])
               sensor_id.append(dataSensor['sensor_id'][i])
               sensor_name.append(dataSensor['sensor_name'][i]) 
               sensor_value.append(dataSensor['sensor_value'][i])
        num_sensor = len(id)       
        return id, sensor_id, sensor_name, sensor_value, num_sensor             

def calibrateSensor(id, value):
    calibrate_value, sensor_calibrate = [], []
    for i in range(len(id)):
        get_calibrate = sensor.selectCalibrateById(id[i])
        for x in get_calibrate:
            calibrate = x[0]
            formula = x[1]
        sensor_calibrate.append(calibrate)    
        if str(calibrate) == '0':
           coefA, coefB = 1, 0
           values = value[i]
        elif str(calibrate) == '1':
           get_formula = calibrateFormula.selectById(formula)
           for y in get_formula:
               coefA = float(y[3])
               coefB = float(y[4])
           values = (coefA*value[i]) + coefB
           values = round(values,2)
           if values < 0:
              values = 0.00
        calibrate_value.append(values)       
    return calibrate_value, sensor_calibrate        

def createNotifSensor(id_sensor, name_sensor, value, limit, type_notif, unit, timestamp):
    id_device, name, ip, firm_user, firm_pass = getSetting()
    unix = datetime.datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
    unix = int(unix.timestamp())
    subject = name + " - Sensor " + name_sensor + " Warning Notification %23" + str(unix)
    device = name + " (" + id_device + ")"
    sensors = name_sensor + " (" + id_sensor + ")"
    email_message = '<b>' + name + '</b> - <b>' + name_sensor + "</b> value is <b>" + str(value) + " " + unit + "</b> "
    wa_message = '*' + name + '* - *' + name_sensor + "* value is *" + str(value) + " " + unit + "* "
    web_message = name + ' - ' + name_sensor + " value is " + str(value) + " " + unit 
    if type_notif == 'max':
       wa_message += ' reach the highest value limit *' + str(limit) + " " + unit + '* at *' + timestamp + '*'
       email_message += ' reach the highest value limit <b>' + str(limit) + " " + unit + '</b> at <b>' + timestamp + '</b>'
       web_message += ' reach the highest value limit ' + str(limit) + " " + unit + ' at ' + timestamp
    elif type_notif == 'min':    
       wa_message += ' reach the lowest value limit *' + str(limit) + " " + unit + '* at *' + timestamp + '*'
       email_message += ' reach the lowest value limit <b>' + str(limit) + " " + unit + '</b> at <b>' + timestamp + '</b>'
       web_message += ' reach the lowest value limit ' + str(limit) + " " + unit + ' at ' + timestamp
    logNotif.insert("Sensor","Web","-",web_message,"Waiting",timestamp)
    logNotif.insert("Sensor","Whatsapp","-",wa_message,"Waiting",timestamp)
    logNotif.insert("Sensor","Email",subject,email_message,"Waiting",timestamp) 
    
def createNotifNode():
    id_device, name, ip, firm_user, firm_pass = getSetting()
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    unix = datetime.datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
    unix = int(unix.timestamp())
    subject = name + " - Notification %23" + str(unix)
    email_message = 'Device <b>' + name + '</b> with Device UID <b>' + id_device + "</b> is <b> Power On </b> at <b>" + timestamp + "</b> "
    wa_message = 'Device *' + name + '* with Device UID *' + id_device + "* is *Power On* at *" + timestamp + "* "
    web_message = 'Device ' + name + ' with Device UID ' + id_device + " is Power On at " + timestamp
    logNotif.insert("Device","Web","-",web_message,"Waiting",timestamp)
    logNotif.insert("Device","Whatsapp","-",wa_message,"Waiting",timestamp)
    logNotif.insert("Device","Email",subject,email_message,"Waiting",timestamp)  

def createApiPRTG(dataSensor, returnApi, x, log, monitor, api):
    if api == 'groupOnly':
       if dataSensor['oid_type'][x] == 1:
          sensor_value = '-1'
       else:
          sensor_value = dataSensor['sensor_value'][x] 
       result = {'channel':dataSensor['sensor_id'][x],'value':sensor_value}
       returnApi['prtg']['result'].append(result) 
    else:    
       if dataSensor['sensor_log'][x] == log and dataSensor['sensor_monitor'][x] == monitor:
          if dataSensor['oid_type'][x] == 1:
             sensor_value = '-1'
          else:
             sensor_value = dataSensor['sensor_value'][x]
          result = {'channel':dataSensor['sensor_id'][x],'value':sensor_value}
          returnApi['prtg']['result'].append(result)
    return returnApi   

def processApiPRTG(sensors, priority):
    if sensors == 'connex':
       group, stateGroup = 'connex', 1
    elif sensors == 'bsp':
       group, stateGroup = 3, 1
    elif sensors == 'modem':
       group, stateGroup = 4, 1
    elif sensors == 'minipc':
       group, stateGroup = 5, 1
    elif sensors == 'internal':
       group, stateGroup = 6, 1
    else:
       group, stateGroup = 0, 0
    if priority != None:
       if int(priority) == 1:
          monitor, log = 1, 1
       elif int(priority) == 2:
          monitor, log = 1, 2 
       elif int(priority) == 3:
          monitor, log = 2, 1 
       elif int(priority) == 4:
          monitor, log = 2, 2 
       elif int(priority) == 5:
          monitor, log = 1, 0 
       elif int(priority) == 6:
          monitor, log = 2, 0
       elif int(priority) == 0:
          monitor, log = 0, 0
       return group, stateGroup, monitor, log
    else:
       return group, stateGroup 
