import sys
sys.path.append('../database')
from sql import *

def syncSensor(URLCheckSensor, id_device, url_sensor, token):
    if URLCheckSensor == 1:
       log_sensor = syncSensorProcess(id_device, url_sensor, token)       
    else:
       log_sensor = 'URL Sensor N/A'
    print('State Sensor Sync : ', log_sensor)     
    return log_sensor   

def syncSensorProcess(id_device, url_sensor, token):
    url_sensor = url_sensor + "?node_id=" + str(id_device)
    #print('URL Sensor : ', url_sensor)
    try:
       tokenData = "token=" + str(token) 
       headers = {"Cookie": tokenData}    
       get_sensor = requests.get(url=url_sensor, timeout=10, headers=headers)
       state = get_sensor.status_code
       sensor_json = get_sensor.json()
       sensor_json = sensor_json['data']                 
    except:
       state = 444    
    if state == 200:
       num_sensor = 0 
       for i in range(len(sensor_json)):
           sensor_id = sensor_json[i]['costume_id']
           sensor_notif = sensor_json[i]['notification']
           if sensor_notif == True:
              sensor_notif = 1 
           elif sensor_notif == False:
              sensor_notif = 0
           sensor_name = sensor_json[i]['name']
           sensor_max = sensor_json[i]['highest_value']
           sensor_min = sensor_json[i]['lowest_value']
           sensor_unit = sensor_json[i]['unit']
           check_sensor = sensor.selectOne(sensor_id)
           if len(check_sensor) > 0:
              num_sensor+=1 
              updateDB = sensor.updateParam(sensor_name, sensor_notif, sensor_max, sensor_min, sensor_unit, sensor_id) 
       #print('Sensor (Server) : ', len(sensor_json), ' Sensors')
       #print('Sensor (Device) : ', num_sensor, 'Sensors')
       log_sensor = "Success Sync " + str(num_sensor) + " of " + str(len(sensor_json)) + " Sensors"
    else:
       log_sensor = 'Failed to Sync Sensor'
    #print('State Sensor Sync : ', log_sensor)   
    return log_sensor   
