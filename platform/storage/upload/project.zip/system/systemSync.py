import sys, time, json, requests, os
from threading import Thread
from syncNode import syncNode
from syncSensor import syncSensor
sys.path.append('../../library')
from SynapsisLibrary import times
sys.path.append('../database')
from sql import *
from function import getSetting, getInterval, getURL, checkURL, checkTokenHTTP, getConnexSetting

w1 = times.getDatetime()
print("Start : ", w1)
update_reboot = 0

class ThreadWithReturnValue(Thread):
    def __init__(self, group=None, target=None, name=None,
                 args=(), kwargs={}, Verbose=None):
        Thread.__init__(self, group, target, name, args, kwargs)
        self._return = None
    def run(self):
        if self._target is not None:
            self._return = self._target(*self._args,
                                                **self._kwargs)
    def join(self, *args):
        Thread.join(self, *args)
        return self._return

def main():
    global update_reboot
    
    now2 = times.now()
    timestamp = now2.strftime("%Y-%m-%d %H:%M:%S")
    now2 = int((now2.minute*60)+now2.second)
    
    ### GET INTERVAL ###
    interval = getInterval("sync")
    frekuensi = 1
    ####################
    
    ### GET DEVICE INFO ####
    id_device, name, ip, firm_user, firm_pass = getSetting()
    monitoring, sync, log, notif = getConnexSetting()
    ########################
    
    log = ''
    print("----- ", timestamp, " -----")
    if sync == 0:
       system.updateStatusByName("Connex Synchronize Setting Inactive", timestamp, "connex_sync")  
       print("Connex Synchronize Setting Inactive")
       print("---------------------------------")
    else:
       stateToken, tokenData, expireToken = checkTokenHTTP()
       if int(stateToken) == 1: 
          threads = [] 
          ###### Sync Node ######
          url_node = getURL(ip, "node")
          URLCheckNode = checkURL(url_node)
          node_thread = ThreadWithReturnValue(target=syncNode, args=(URLCheckNode, id_device, url_node, tokenData, update_reboot))
          threads.append(node_thread)
          node_thread.start()
          #######################
          ###### Sync Sensor ######
          url_sensor = getURL(ip, "sensor")
          URLCheckSensor = checkURL(url_sensor)
          sensor_thread = ThreadWithReturnValue(target=syncSensor, args=(URLCheckSensor, id_device, url_sensor, tokenData))
          threads.append(sensor_thread)
          sensor_thread.start()
          #########################
          for x in range(len(threads)):
              if x == 0:
                 log_node = threads[x].join()
              elif x == 1:
                 log_sensor = threads[x].join()
          update_reboot = log_node[1]              
          log_sync = log_node[0] + ' | ' + log_sensor
       else:
          print('State : No Authentication') 
          log_sync = 'No Authentication'    
       print("---------------------------------")
       system.updateStatusByName(log_sync, timestamp, "connex_sync")    
       print("")
    time.sleep(interval)


while True:
      if __name__ == '__main__':
         main()
