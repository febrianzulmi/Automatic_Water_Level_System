import time, sys
sys.path.append('../database')
from sql import *
from sql_connex import *
from function import *

def main():
    get_service = services.select()
    for i in range(len(get_service)):
        service_name = get_service[i][1]
        get_system = system.selectByName(service_name)
        state = checkActiveService(service_name)
        enable = checkEnableService(service_name)
        if enable == 'disabled' and state == 'inactive':
           since, last_run = '-', '-'
        else:    
           last_run, since = checkDetailService(service_name)
        if len(get_system) > 0:
           system.updateServiceByName(state,enable,last_run,since,service_name)
        else:
           system.insert(service_name,state,enable,last_run,since)      
        print(get_service[i][1], '|', state, '|', enable, '|', last_run, '|', since)
    print("")
    
    time.sleep(5)
    
    
while True:
    if __name__ == '__main__': main()
