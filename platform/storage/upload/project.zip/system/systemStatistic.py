import time, sys
sys.path.append('../database')
from sql import *
from function import *

def calculateLog(name):
    if name == 'monitoring':
       log = logSendNode.selectAll()
    elif name == 'buffer':
       log = logBufferNode.selectAll()
    elif name == 'log' :
       log = logSensor.selectAll()
    elif name == 'notif' :
       log = logNotif.selectAll()   
    statistic.updateValueByName(len(log), name)
    print(name, ' - ', len(log))  
       
def main():
    data = statistic.select()
    if len(data) > 0:
       for i in range(len(data)):
           name = data[i][1]
           calculateLog(name)    
    print("")
    time.sleep(30)
    
    
while True:
    if __name__ == '__main__': main()
