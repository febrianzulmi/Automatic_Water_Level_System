import sys, requests
sys.path.append('../database')
from sql import *

def syncNode(URLCheckNode, id_device, url_node, token, update_reboot):
    if URLCheckNode == 1:
       log_node, update_reboot = syncNodeProcess(id_device, url_node, token, update_reboot)       
    else:
       log_node = 'URL Node N/A'
    print('State Node Sync : ', log_node)     
    return log_node, update_reboot 

def syncNodeProcess(id_device, url_node, token, update_reboot):
    url_node = url_node + "/" + str(id_device)
    log_reboot = ''
    if update_reboot == 0:
       url_reboot = url_node + '/reboot'
       #print("URL Reboot : ", url_reboot)
       log_reboot, update_reboot = updateReboot(token, url_reboot, update_reboot)       
    #print("URL Node : ", url_node)
    try:   
       tokenData = "token=" + str(token) 
       headers = {"Cookie": tokenData}     
       get_node = requests.get(url=url_node, timeout=10, headers=headers)
       node_json = get_node.json()
       state = get_node.status_code
       node_json = node_json['data']
    except:
       state = 444    
    if state == 200:
       interval = node_json['interval']
       name_device = node_json['name']
       reboot_state = node_json['reboot_status']
       #print("Device Name : ", name_device)
       #print("Interval Monitoring : " + str(interval) + " (Seconds)")
       if int(interval) < 60:
          interval = int(interval)
          unit = 1  
       elif int(interval) >= 60 and int(interval) < 3600:
          interval = int(interval)/60
          unit = 2
       elif int(interval) >= 3600:
          interval = int(interval)/3600
          unit = 3 
       updateInterval = intervals.updateByName(interval, unit, "monitoring")
       updateName = setting.updateName(name_device)
       log_node = 'Success Sync Node' 
       if int(reboot_state) == 1:
          #print("State Reboot : Reboot Detected")
          os.system("sudo reboot")  
       if log_reboot != '':
          log_node = log_node + " - " + log_reboot      
    else:
       log_node = 'Failed to Sync Node'
    #print('State Node Sync : ', log_node)
    return log_node, update_reboot   

def updateReboot(token, url_reboot, update_reboot):
    try:
       tokenData = "token=" + str(token) 
       headers = {"content-type": "application/json", "Cookie": tokenData} 
       reboot_json = {"reboot_status":0}
       reboot_json = json.dumps(reboot_json)
       post_data = requests.put(url=url_reboot, data=reboot_json, headers=headers, timeout=10)
       state = post_data.status_code
    except:
       state = 444
    if state == 200:    
       print("State Reboot : Success Update Reboot State")
       update_reboot = 1
       return 'Success Update Reboot State', update_reboot
    else:
       print("State Reboot : Failed Update Reboot State (" + str(state) + ")")  
       return 'Failed Update Reboot State', update_reboot 
