import sys, time, requests
sys.path.append('../database')
from sql import *
from function import *

now = times.now()
time1 = int((now.minute*60)+now.second)

def sendNotif(node_id, tokenData, url_notif, subject_message, notif_message, type_message, types):
    url_notif = url_notif + '/send?node_id=' + str(node_id)
    if type_message == 'email':
       url_notif = url_notif + '&subject=' + str(subject_message)
    elif type_message == 'web':
       if types == 'Device':
          url_notif = url_notif + '&level=1'
       else:  
          url_notif = url_notif + '&level=5'            
    url_notif = url_notif + '&message=' + str(notif_message) + '&type=' + str(type_message)
    print(url_notif)  
    try:
       tokenData = "token=" + str(tokenData) 
       headers = {"Cookie": tokenData}    
       send = requests.post(url_notif, timeout=10, headers=headers)
       status_code = send.status_code
    except Exception as e:
       status_code = 444
    return status_code

def checkNotif(node_id, tokenData, url_notif, timestamp):
    get_log = logNotif.selectByState()
    print("Notif : ", len(get_log), " Data")
    sensor_success, sensor_failed = 0, 0
    device_success, device_failed = 0, 0
    #actuator_success, actuator_failed = 0, 0 
    if len(get_log) > 0:
       for i in range(len(get_log)): 
           id_notif = get_log[i][0]
           types = get_log[i][1]
           subject = get_log[i][3]
           message = get_log[i][4]
           notif = get_log[i][2]
           send_time = get_log[i][7]
           if notif == "Web":
              code = sendNotif(node_id, tokenData, url_notif, subject, message, "web", types)
           elif notif == "Whatsapp":
              code = sendNotif(node_id, tokenData, url_notif, subject, message, "wa", types)
           elif notif == "Email":
              code = sendNotif(node_id, tokenData, url_notif, subject, message, "email", types)
           if code == 200:
              logNotif.updateNotif(id_notif, "Success", timestamp)
              if types == 'Sensor':
                 sensor_success += 1
              elif types == 'Device':
                 device_success += 1                     
           else:
              logNotif.updateNotif(id_notif, "Failed", send_time)    
              if types == 'Sensor':
                 sensor_failed += 1
              elif types == 'Device':
                 device_failed += 1   
       sensor = sensor_success + sensor_failed
       device = device_success + device_failed
       #actuator = actuator_success + actuator_failed
       success = sensor_success + device_success
       failed = sensor_failed + device_failed           
       debug = "=> " + str(sensor) + " Sensor Notif (" + str(sensor_success) + " Success - " + str(sensor_failed) + " Failed)"
       print(debug)
       debug = "=> " + str(device) + " Device Notif (" + str(device_success) + " Success - " + str(device_failed) + " Failed)"
       print(debug)
       #debug = "=> " + str(actuator) + " Actuator Notif (" + str(actuator_success) + " Success - " + str(actuator_failed) + " Failed)"
       #print(debug)
       log = str(len(get_log)) + " Notif Data (" + str(success) + " Success - " + str(failed) + " Failed)"
       system.updateStatusByName(log, timestamp, "connex_notif")    
    else:
       system.updateStatusByName("No Notif", timestamp, "connex_notif")          
    
def main():
    global time1
    now2 = times.now()
    timestamp = now2.strftime("%Y-%m-%d %H:%M:%S")
    time2 = int((now2.minute*60)+now2.second)  
    
    ### GET DEVICE INFO ####
    id_device, name, ip, firm_user, firm_pass = getSetting()
    ########################
    
    ### GET INTERVAL ###
    interval = getInterval("notif")
    frekuensi = 1
    ####################

    if id_device == '' or id_device == None:
       print("----- ", timestamp, " -----")
       print("ID Device : Undefined")
       print("---------------------------------")
       print("")
       system.updateStatusByName("ID Device N/A", timestamp, "connex_notif")
          
    else:
       print("----- ", timestamp, " -----")
       url_notif = getURL(ip, "notification")
       URLCheck = checkURL(url_notif)
       print("URL : ", url_notif)
       if URLCheck == 1:
          stateToken, tokenData, expireToken = checkTokenHTTP()
          if int(stateToken) == 1:
             checkNotif(id_device, tokenData, url_notif, timestamp)
          else:
             system.updateStatusByName("No Authentication", timestamp, "connex_notif") 
       else:
          system.updateStatusByName("URL N/A", timestamp, "connex_notif")           
       print("---------------------------------")
       print("")   
    time.sleep(interval)
    
while True:
      if __name__ == '__main__':
         main()
