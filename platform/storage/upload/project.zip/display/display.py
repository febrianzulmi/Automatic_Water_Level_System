import serial, time, datetime, sys, json, threading
from function_display import *
sys.path.append('../database')
from function import *
from sql_connex import *
from sql import *

ser = serial.Serial('/dev/ttyS0', 9600, timeout=3)

def write(command):
    end = b'\xff\xff\xff'
    encodes = command.encode('ascii')
    commands  = encodes + end
    ser.write(commands)
    
def command_set(command):
    write(command)
 
def setGroup(state_name, last_name, last_update):
    command_set(last_name + '.txt=\"' + str(last_update) + '\"')
    command_set(state_name + '.pco=0')  

def setServiceError(name):
    command_set(name + '.txt=\"Error\"') 
    command_set(name + '.bco=64512')  

def setServiceRunning(name):
    command_set(name + '.txt=\"Running\"') 
    command_set(name + '.bco=2016') 

def setServiceStop(name):
    command_set(name + '.txt=\"Stop\"') 
    command_set(name + '.bco=63488')      

def setMenuBar(now):
    times = now.strftime("%H:%M:%S")
    days = now.strftime("%d/%m/%y")
    id_device, name, ip, firm_user, firm_pass = getSetting()
    temp = getTemp()
    fan = getFan()
    command_set('id.txt=\"' + id_device + '\"')
    command_set('name.txt=\"' + name + '\"')
    command_set('date.txt=\"' + days + '\"')
    command_set('time.txt=\"' + times + '\"')
    command_set('suhu.txt=\"' + str(temp) + ' C\"')
    command_set('fan.txt=\"' + str(fan) + ' %\"')
    
    if temp != "N/A":
       if float(temp) > 70.0:
          command_set('suhu.pco=63488')
       else:
          command_set('suhu.pco=65535')
    else:
       command_set('suhu.pco=63488')     

def setHome():
    uptime, boot_time = getUptime()
    ipwlan = getInterface('wlan0')
    ssid = getSSID('wlan0')
    ipeth = getInterface('eth0')
    cpu = getUsage()
    cputemp = getCPUTemp()
    get_wifi = wireless.selectAll()
    for x in range(len(get_wifi)):
        if get_wifi[x][0] == 'station':
           state_station = get_wifi[x][2]
           ssid_station = get_wifi[x][3]
        elif get_wifi[x][0] == 'hotspot':
           state_hotspot = get_wifi[x][2]
           ssid_hotspot = get_wifi[x][3]    
    if state_station == 0:
       command_set('home.logowlan.pic=10') 
       command_set('home.ssid.txt=\"' + str(ssid_hotspot) + '\"')
       command_set('home.ipwlan.txt=\"' + ipwlan + '\"')
    elif state_station == 1:
       command_set('home.logowlan.pic=7')  
       if ssid == "-":
          command_set('home.ipwlan.txt=\"IP Undefined\"')
          command_set('home.ssid.txt=\"SSID Undefined\"')
       else:
          command_set('home.ssid.txt=\"' + str(ssid) + '\"')
          command_set('home.ipwlan.txt=\"' + ipwlan + '\"')          
               
    command_set('home.ipeth.txt=\"' + str(ipeth) + '\"')
    command_set('home.uptime.txt=\"'+ uptime + '\"')
    command_set('home.lastboot.txt=\"'+ boot_time + '\"')
    command_set('home.cpu.txt=\"'+ cpu + '\"')
    command_set('home.cputemp.txt=\"'+ cputemp + ' C\"')       

def setSensor():
    id, sensor_id, sensor_name, sensor_value, num_sensor = getDataSensor.priorityLog()
    mcbBSPVoltage, loadBSPCurrent, lvdBSPVoltage = sensor_value[0], sensor_value[1], sensor_value[2]
    vPV, vBatt, aChg = sensor_value[3], sensor_value[4], sensor_value[5]
    forwardPower, satSync, satRx, plpFill = sensor_value[6], sensor_value[7], sensor_value[8], sensor_value[9]
    group_data = groups.select()
    for i in range(len(group_data)):
        group_id = group_data[i][0]
        serviceName = "sensor" + str(group_id)
        service, state_sensor, last_update = getServiceState(serviceName)
        print(serviceName, ' - ', service)
        scc_config = getParameterListSensor(group_id, "config_id")
        scc_id, scc_type = None, None
        getConfig = sccConfig.selectById(scc_config)
        for x in getConfig:
            scc_id = x[1]
        getSCC = sccType.selectById(scc_id)
        for y in getSCC:
            scc_type = y[1] 
        if int(group_id) == 1:
           state = stateProcessSensor("load.stateload", "load.lastload", last_update, state_sensor, service) 
           if state == 0:
              mcbBSPVoltage, loadBSPCurrent, lvdBSPVoltage  = 0.00, 0.00, 0.00 
           elif state == 2:
              mcbBSPVoltage, loadBSPCurrent, lvdBSPVoltage = 'N/A', 'N/A', 'N/A'                 
        elif int(group_id) == 2:
            command_set('scc.scctype.txt=\"' + str(scc_type) + '\"')
            state = stateProcessSensor("scc.statescc", "scc.lastscc", last_update, state_sensor, service)
            if state == 0:
               vPV, vBatt, aChg  = 0.00, 0.00, 0.00
            elif state == 2:
               vPV, vBatt, aChg  = 'N/A', 'N/A', 'N/A'
        elif int(group_id) == 3:
            command_set('bsp.bsptype.txt=\"' + str(scc_type) + '\"')
            state = stateProcessSensor("bsp.statebsp", "bsp.lastbsp", last_update, state_sensor, service)
            if state == 0:
               forwardPower, satSync, satRx, plpFill = 0, 0, 0, 0
            elif state == 2:
               forwardPower, satSync, satRx, plpFill = 'N/A', 'N/A', 'N/A', 'N/A'         
    # menu scc 
    command_set('scc.vPVLabel.txt=\"PV Voltage\"')
    command_set('scc.vPV.txt=\"' + str(vPV) + ' V\"')
    command_set('scc.vBattLabel.txt=\"Battery Voltage\"')
    command_set('scc.vBatt.txt=\"' + str(vBatt) + ' V\"')
    command_set('scc.aChgLabel.txt=\"Charging Current\"')
    command_set('scc.aChg.txt=\"' + str(aChg) + ' A\"')
    
    #menu load
    command_set('load.mcbBSPLabel.txt=\"MCB BSP Voltage\"')
    command_set('load.mcbBSP.txt=\"' + str(mcbBSPVoltage) + ' V\"')
    command_set('load.vBSPLabel.txt=\"Lvd BSP Voltage\"')
    command_set('load.vBSP.txt=\"' + str(lvdBSPVoltage) + ' V\"')
    command_set('load.aBSPLabel.txt=\"Load BSP Current\"')
    command_set('load.aBSP.txt=\"' + str(loadBSPCurrent) + ' A\"')
    
    #menu bsp
    command_set('bsp.fPowerLabel.txt=\"Forward Power\"')
    command_set('bsp.forwardPower.txt=\"' + str(forwardPower) + ' W\"')
    command_set('bsp.satSyncLabel.txt=\"Sat1 Sync OK\"')
    command_set('bsp.satSync.txt=\"' + str(satSync) + '\"')
    command_set('bsp.rxLevelLabel.txt=\"Sat1 Rx Level\"')
    command_set('bsp.satRxLevel.txt=\"' + str(satRx) + '\"')
    
def stateProcessSensor(state_name, last_name, last_update, state_sensor, service):
    if service == "active":
       setGroup(state_name,last_name,last_update)
       if 'Success' in state_sensor:
          setServiceRunning(state_name) 
          state = 1
       else:
          setServiceError(state_name)
          state = 0
    else:
       setGroup(state_name,last_name, "N/A") 
       setServiceStop(state_name)
       state = 2
    return state  

command_set('page 0')

while  True:
    print("Start")
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    print(timestamp)
    try:
       threads = []
       menu_thread= threading.Thread(target = setMenuBar, args=[now])
       menu_thread.start()
       threads.append(menu_thread)
       home_thread= threading.Thread(target = setHome)
       home_thread.start()
       threads.append(home_thread)
       sensor_thread= threading.Thread(target = setSensor)
       sensor_thread.start()
       threads.append(sensor_thread)
       for i  in threads:
           i.join()
       a = system.updateStatusByName("Running", timestamp, "connex_display")
    except Exception as e:
       system.updateStatusByName(str(e), timestamp, "Display")
       print(e)
    print("")    
    time.sleep(1)

    
